//#region node_modules/.nitro/vite/services/ssr/assets/assets-BKSD5_lQ.js
var ASSETS = [
	{
		id: "eurusd",
		pair: "EUR/USD",
		name: "Euro / Dólar",
		class: "forex",
		decimals: 5,
		biquote: "EURUSD",
		fallbacks: [
			{
				kind: "twelve",
				symbol: "EUR/USD"
			},
			{
				kind: "okx-index",
				instId: "EUR-USD"
			},
			{
				kind: "yahoo",
				ticker: "EURUSD=X"
			}
		]
	},
	{
		id: "gbpusd",
		pair: "GBP/USD",
		name: "Libra / Dólar",
		class: "forex",
		decimals: 5,
		biquote: "GBPUSD",
		fallbacks: [{
			kind: "yahoo",
			ticker: "GBPUSD=X"
		}]
	},
	{
		id: "usdjpy",
		pair: "USD/JPY",
		name: "Dólar / Iene",
		class: "forex",
		decimals: 3,
		biquote: "USDJPY",
		fallbacks: [{
			kind: "okx-index",
			instId: "USD-JPY"
		}, {
			kind: "yahoo",
			ticker: "JPY=X"
		}]
	},
	{
		id: "audusd",
		pair: "AUD/USD",
		name: "Aussie / Dólar",
		class: "forex",
		decimals: 5,
		biquote: "AUDUSD",
		fallbacks: [{
			kind: "okx-index",
			instId: "AUD-USD"
		}, {
			kind: "yahoo",
			ticker: "AUDUSD=X"
		}]
	},
	{
		id: "eurjpy",
		pair: "EUR/JPY",
		name: "Euro / Iene",
		class: "forex",
		decimals: 3,
		biquote: "EURJPY",
		fallbacks: [{
			kind: "yahoo",
			ticker: "EURJPY=X"
		}]
	},
	{
		id: "eurgbp",
		pair: "EUR/GBP",
		name: "Euro / Libra",
		class: "forex",
		decimals: 5,
		biquote: "EURGBP",
		fallbacks: [{
			kind: "yahoo",
			ticker: "EURGBP=X"
		}]
	},
	{
		id: "xauusd",
		pair: "XAU/USD",
		name: "Ouro",
		class: "commodity",
		decimals: 2,
		biquote: "XAUUSD",
		fallbacks: [{
			kind: "okx-index",
			instId: "XAU-USD"
		}, {
			kind: "yahoo",
			ticker: "GC=F"
		}]
	},
	{
		id: "btcusd",
		pair: "BTC/USD",
		name: "Bitcoin",
		class: "crypto",
		decimals: 2,
		biquote: "BTCUSD",
		fallbacks: [
			{
				kind: "coinbase",
				product: "BTC-USD"
			},
			{
				kind: "okx",
				instId: "BTC-USDT"
			},
			{
				kind: "yahoo",
				ticker: "BTC-USD"
			}
		]
	},
	{
		id: "ethusd",
		pair: "ETH/USD",
		name: "Ethereum",
		class: "crypto",
		decimals: 2,
		biquote: "ETHUSD",
		fallbacks: [
			{
				kind: "coinbase",
				product: "ETH-USD"
			},
			{
				kind: "okx",
				instId: "ETH-USDT"
			},
			{
				kind: "yahoo",
				ticker: "ETH-USD"
			}
		]
	},
	{
		id: "solusd",
		pair: "SOL/USD",
		name: "Solana",
		class: "crypto",
		decimals: 3,
		biquote: "SOLUSD",
		fallbacks: [
			{
				kind: "coinbase",
				product: "SOL-USD"
			},
			{
				kind: "okx",
				instId: "SOL-USDT"
			},
			{
				kind: "yahoo",
				ticker: "SOL-USD"
			}
		]
	}
];
var ASSET_MAP = Object.fromEntries(ASSETS.map((a) => [a.id, a]));
function matchesMarket(asset, market) {
	if (market === "all") return true;
	if (market === "crypto") return asset.class === "crypto";
	return asset.class !== "crypto";
}
var INTERVAL_MS = {
	"1m": 6e4,
	"5m": 3e5
};
//#endregion
export { matchesMarket as i, ASSET_MAP as n, INTERVAL_MS as r, ASSETS as t };
