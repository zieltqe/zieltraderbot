import { i as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { i as matchesMarket, n as ASSET_MAP } from "./assets-BKSD5_lQ.mjs";
import { a as RefreshCw, c as Clock, d as Activity, i as ShieldAlert, l as ChevronRight, n as TrendingUp, o as Radio, r as TrendingDown, s as History, u as ChartColumn } from "../_libs/lucide-react.mjs";
import { n as Route, r as getSignalFeed } from "./router-B5F40wYk.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CPq3hQb-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MAX = 120;
var useHistoryStore = create()(persist((set, get) => ({
	items: [],
	ingest: (signals) => {
		const tradeable = signals.filter((s) => s.tradeable);
		if (!tradeable.length) return;
		const next = [...get().items];
		for (const s of tradeable) {
			const id = `${s.assetId}:${s.interval}:${s.expiryAt}`;
			if (next.some((i) => i.id === id)) continue;
			next.unshift({
				id,
				assetId: s.assetId,
				interval: s.interval,
				direction: s.direction,
				confidence: s.confidence,
				quality: s.quality,
				entryPrice: s.entryPrice,
				issuedAt: s.issuedAt,
				expiryAt: s.expiryAt,
				result: "pending"
			});
		}
		set({ items: next.slice(0, MAX) });
	},
	settle: (quotes, now) => {
		const byId = new Map(quotes.map((q) => [q.assetId, q]));
		let changed = false;
		const items = get().items.map((item) => {
			if (item.result !== "pending") return item;
			if (item.expiryAt > now + 400) return item;
			const quote = byId.get(item.assetId);
			if (!quote) return item;
			const exit = quote.price;
			const delta = exit - item.entryPrice;
			const eps = Math.max(item.entryPrice * 1e-6, 1e-8);
			let result = "void";
			if (Math.abs(delta) > eps) result = item.direction === "call" && delta > 0 || item.direction === "put" && delta < 0 ? "win" : "loss";
			changed = true;
			return {
				...item,
				exitPrice: exit,
				result
			};
		});
		if (changed) set({ items });
	},
	clear: () => set({ items: [] })
}), { name: "nexa-history" }));
function summarize(items) {
	const settled = items.filter((i) => i.result === "win" || i.result === "loss");
	const wins = settled.filter((i) => i.result === "win").length;
	const losses = settled.filter((i) => i.result === "loss").length;
	const pending = items.filter((i) => i.result === "pending").length;
	const hitRate = settled.length ? wins / settled.length : 0;
	let streak = 0;
	for (const item of items) {
		if (item.result === "pending" || item.result === "void") continue;
		if (streak === 0) {
			streak = item.result === "win" ? 1 : -1;
			continue;
		}
		if (streak > 0 && item.result === "win") streak++;
		else if (streak < 0 && item.result === "loss") streak--;
		else break;
	}
	const byAsset = /* @__PURE__ */ new Map();
	for (const item of settled) {
		const cur = byAsset.get(item.assetId) ?? {
			wins: 0,
			n: 0
		};
		cur.n += 1;
		if (item.result === "win") cur.wins += 1;
		byAsset.set(item.assetId, cur);
	}
	let best = null;
	for (const [assetId, v] of byAsset) {
		if (v.n < 3) continue;
		const rate = v.wins / v.n;
		if (!best || rate > best.hitRate) best = {
			assetId,
			hitRate: rate,
			n: v.n
		};
	}
	return {
		wins,
		losses,
		pending,
		settled: settled.length,
		hitRate,
		streak,
		best
	};
}
var useUiStore = create()((set) => ({
	tab: "sinais",
	interval: "1m",
	market: "forex",
	selectedId: "eurusd",
	setTab: (tab) => set({ tab }),
	setInterval: (interval) => set({ interval }),
	setMarket: (market) => set((s) => {
		const asset = ASSET_MAP[s.selectedId];
		let selectedId = s.selectedId;
		if (market === "forex" && asset?.class === "crypto") selectedId = "eurusd";
		if (market === "crypto" && asset?.class !== "crypto") selectedId = "btcusd";
		return {
			market,
			selectedId
		};
	}),
	setSelectedId: (selectedId) => set({
		selectedId,
		tab: "sinais"
	})
}));
var useGateStore = create()(persist((set) => ({
	accepted: false,
	accept: () => set({ accepted: true })
}), { name: "nexa-gate" }));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatPrice(value, decimals) {
	return new Intl.NumberFormat("pt-BR", {
		minimumFractionDigits: decimals,
		maximumFractionDigits: decimals
	}).format(value);
}
function formatTime(ts) {
	return new Intl.DateTimeFormat("pt-BR", {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	}).format(ts);
}
function pad2(n) {
	return String(n).padStart(2, "0");
}
function CandleChart({ candles, direction, className }) {
	const slice = candles.slice(-40);
	if (slice.length < 4) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-36 rounded-xl bg-elevated", className) });
	const min = Math.min(...slice.map((c) => c.low));
	const max = Math.max(...slice.map((c) => c.high));
	const pad = (max - min) * .08 || 1;
	const lo = min - pad;
	const hi = max + pad;
	const w = 320;
	const h = 140;
	const gap = 1.4;
	const cw = (w - gap * slice.length) / slice.length;
	const y = (price) => (hi - price) / (hi - lo) * h;
	const last = slice[slice.length - 1];
	const lastY = y(last.close);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: cn("h-36 w-full overflow-visible", className),
		role: "img",
		"aria-label": "Gráfico de velas",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "0",
				x2: w,
				y1: lastY,
				y2: lastY,
				className: "stroke-border",
				strokeDasharray: "3 4",
				strokeWidth: "1"
			}),
			slice.map((c, i) => {
				const x = i * (cw + gap);
				const up = c.close >= c.open;
				const top = y(Math.max(c.open, c.close));
				const bot = y(Math.min(c.open, c.close));
				const body = Math.max(bot - top, 1.2);
				const forming = !c.closed && i === slice.length - 1;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					className: up ? "text-call" : "text-put",
					opacity: forming ? .55 : 1,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: x + cw / 2,
						x2: x + cw / 2,
						y1: y(c.high),
						y2: y(c.low),
						stroke: "currentColor",
						strokeWidth: "1"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x,
						y: top,
						width: cw,
						height: body,
						rx: "0.6",
						fill: "currentColor"
					})]
				}, c.time);
			}),
			direction ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: w - cw / 2,
				cy: lastY,
				r: "2.4",
				className: direction === "call" ? "fill-call" : "fill-put"
			}) : null
		]
	});
}
function Sparkline({ values, up }) {
	if (values.length < 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-16" });
	const min = Math.min(...values);
	const span = Math.max(...values) - min || 1;
	const d = values.map((v, i) => {
		const x = i / (values.length - 1) * 64;
		const y = 18 - (v - min) / span * 16;
		return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
	}).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 64 20",
		className: "h-8 w-16",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d,
			fill: "none",
			className: up ? "stroke-call" : "stroke-put",
			strokeWidth: "1.6",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	});
}
var CLASS_LABEL = {
	forex: "Forex",
	crypto: "Cripto",
	commodity: "Ouro"
};
function AssetsView({ snapshots }) {
	const setSelectedId = useUiStore((s) => s.setSelectedId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-2 pb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "px-1 pb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-semibold",
				children: "Ativos"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Cotações reais em USD. Toque para abrir o sinal de EUR/USD ou outro par."
			})]
		}), snapshots.map((snap) => {
			const asset = ASSET_MAP[snap.quote.assetId];
			if (!asset) return null;
			const up = snap.quote.changePct >= 0;
			const live = Boolean(snap.signal?.tradeable);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setSelectedId(asset.id),
				className: "flex w-full items-center gap-3 rounded-xl bg-surface px-3 py-3 text-left shadow-[var(--shadow-border)] transition-transform duration-150 ease-out active:scale-[0.98]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: asset.pair
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] uppercase tracking-wide text-subtle",
								children: CLASS_LABEL[asset.class]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block text-xs text-muted",
							children: asset.name
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
						values: snap.quote.spark,
						up
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "w-24 text-right",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-mono text-sm tabular-nums",
								children: formatPrice(snap.quote.price, asset.decimals)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: cn("text-xs tabular-nums", up ? "text-call" : "text-put"),
								children: [
									up ? "+" : "",
									snap.quote.changePct.toFixed(2).replace(".", ","),
									"%"
								]
							}),
							live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-[10px] uppercase tracking-wide text-accent",
								children: "Sinal ativo"
							}) : null
						]
					})
				]
			}, asset.id);
		})]
	});
}
var TABS = [
	{
		id: "sinais",
		label: "Sinais",
		icon: Radio
	},
	{
		id: "ativos",
		label: "Ativos",
		icon: Activity
	},
	{
		id: "historico",
		label: "Histórico",
		icon: History
	},
	{
		id: "desempenho",
		label: "Desempenho",
		icon: ChartColumn
	}
];
function BottomNav() {
	const tab = useUiStore((s) => s.tab);
	const setTab = useUiStore((s) => s.setTab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm",
		"aria-label": "Navegação principal",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mx-auto grid max-w-lg grid-cols-4",
			children: TABS.map((item) => {
				const active = tab === item.id;
				const Icon = item.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTab(item.id),
					className: cn("flex h-16 w-full flex-col items-center justify-center gap-1 text-[11px] font-medium tracking-wide transition-colors duration-150", active ? "text-fg" : "text-subtle"),
					"aria-current": active ? "page" : void 0,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-5",
						strokeWidth: active ? 2.2 : 1.8
					}), item.label]
				}) }, item.id);
			})
		})
	});
}
function LogoMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M4 16.5 9.4 8.2c.3-.45.94-.5 1.32-.1L14.2 12l5.3-8",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.9",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "19.6",
			cy: "4.2",
			r: "1.15",
			fill: "currentColor"
		})]
	});
}
function DisclaimerGate() {
	const accepted = useGateStore((s) => s.accepted);
	const accept = useGateStore((s) => s.accept);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready || accepted) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/80 p-4 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-2xl bg-surface p-5 shadow-[var(--shadow-lift)] sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-10 items-center justify-center rounded-lg bg-elevated text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg font-semibold tracking-tight",
						children: "NEXA"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Sinais EUR/USD, forex e cripto em dólar"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex gap-3 rounded-xl bg-elevated p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "mt-0.5 size-5 shrink-0 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 text-sm leading-relaxed text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Opções binárias digitais são de alto risco e podem resultar na perda total do capital." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A NEXA gera sinais de EUR/USD e outros pares cotados em dólar (não stablecoin) por confluência de indicadores (EMA, RSI, MACD, estocástico, Bollinger, ADX) sobre cotações reais. Isso não é garantia de lucro nem recomendação de investimento." })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: accept,
					className: "mt-5 flex h-12 w-full items-center justify-center rounded-xl bg-fg text-sm font-medium text-bg transition-transform duration-150 ease-out active:scale-[0.96]",
					children: "Entendi, continuar"
				})
			]
		})
	});
}
function FeedList({ snapshots, selectedId }) {
	const setSelectedId = useUiStore((s) => s.setSelectedId);
	const others = snapshots.filter((s) => s.quote.assetId !== selectedId);
	if (!others.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "px-1 text-[11px] font-medium uppercase tracking-[0.16em] text-subtle",
			children: "Outros ativos"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2 space-y-2",
			children: others.map((snap) => {
				const asset = ASSET_MAP[snap.quote.assetId];
				if (!asset) return null;
				const signal = snap.signal;
				const call = (signal?.direction ?? snap.bias?.direction) === "call";
				const live = Boolean(signal?.tradeable);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setSelectedId(asset.id),
					className: "flex w-full items-center gap-3 rounded-xl bg-surface px-3 py-3 text-left shadow-[var(--shadow-border)] transition-transform duration-150 ease-out active:scale-[0.98]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("flex size-9 items-center justify-center rounded-lg", live ? call ? "bg-call-dim text-call" : "bg-put-dim text-put" : "bg-elevated text-muted"),
							children: call ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: asset.pair
								}), live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: cn("rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide", call ? "bg-call-dim text-call" : "bg-put-dim text-put"),
									children: [
										call ? "Alta" : "Baixa",
										" ",
										signal?.confidence
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase tracking-wide text-subtle",
									children: "Aguardar"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-mono text-xs tabular-nums text-muted",
								children: formatPrice(snap.quote.price, asset.decimals)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-subtle" })
					]
				}) }, asset.id);
			})
		})]
	});
}
function ResultBadge({ item }) {
	const v = {
		win: {
			label: "Win",
			className: "bg-call-dim text-call"
		},
		loss: {
			label: "Loss",
			className: "bg-put-dim text-put"
		},
		void: {
			label: "Empate",
			className: "bg-elevated text-muted"
		},
		pending: {
			label: "Aberto",
			className: "bg-elevated text-accent"
		}
	}[item.result];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide", v.className),
		children: v.label
	});
}
function HistoryView() {
	const items = useHistoryStore((s) => s.items);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "px-1 pb-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-semibold",
				children: "Histórico"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Cada sinal é liquidado no fechamento do candle, contra o preço real."
			})]
		}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-surface px-4 py-10 text-center shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "Nenhum sinal ainda"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Quando um setup de confluência aparecer, ele entra aqui automaticamente."
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: items.map((item) => {
				const asset = ASSET_MAP[item.assetId];
				if (!asset) return null;
				const call = item.direction === "call";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 rounded-xl bg-surface px-3 py-3 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: asset.pair
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase tracking-wide text-subtle",
									children: item.interval
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-0.5 text-xs text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: call ? "text-call" : "text-put",
										children: call ? "ALTA" : "BAIXA"
									}),
									" · ",
									formatTime(item.issuedAt),
									" · força ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono tabular-nums",
										children: item.confidence
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 font-mono text-[11px] tabular-nums text-subtle",
								children: [formatPrice(item.entryPrice, asset.decimals), item.exitPrice != null ? ` → ${formatPrice(item.exitPrice, asset.decimals)}` : ""]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultBadge, { item })]
				}, item.id);
			})
		})]
	});
}
function useCountdown(expiryAt, serverNow) {
	const [left, setLeft] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const skew = Date.now() - serverNow;
		const tick = () => setLeft(Math.max(0, expiryAt - (Date.now() - skew)));
		tick();
		const id = window.setInterval(tick, 200);
		return () => window.clearInterval(id);
	}, [expiryAt, serverNow]);
	if (left == null) return {
		left: 0,
		label: "--:--",
		done: false
	};
	const sec = Math.floor(left / 1e3);
	return {
		left,
		label: `${pad2(Math.floor(sec / 60))}:${pad2(sec % 60)}`,
		done: left <= 0
	};
}
function QualityLabel({ quality }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: {
		elite: "Elite",
		strong: "Forte",
		medium: "Médio",
		weak: "Fraco"
	}[quality] });
}
function ConfidenceRing({ value, tone }) {
	const r = 28;
	const c = 2 * Math.PI * r;
	const offset = c - value / 100 * c;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative size-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 72 72",
			className: "size-20 -rotate-90",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "36",
				cy: "36",
				r,
				className: "stroke-border",
				strokeWidth: "5",
				fill: "none"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "36",
				cy: "36",
				r,
				className: tone === "call" ? "stroke-call" : tone === "put" ? "stroke-put" : "stroke-muted",
				strokeWidth: "5",
				fill: "none",
				strokeLinecap: "round",
				strokeDasharray: c,
				strokeDashoffset: offset
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-0 flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-lg font-medium tabular-nums leading-none",
				children: value
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[9px] uppercase tracking-wider text-subtle",
				children: "força"
			})]
		})]
	});
}
function SignalHero({ snapshot, interval }) {
	const asset = ASSET_MAP[snapshot.quote.assetId];
	const signal = snapshot.signal;
	const direction = signal?.direction ?? snapshot.bias?.direction ?? null;
	const call = direction === "call";
	const countdown = useCountdown(signal?.expiryAt ?? Date.now(), signal?.serverNow ?? Date.now());
	if (!asset) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.16em] text-subtle",
						children: interval === "1m" ? "Expiração 1 minuto" : "Expiração 5 minutos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-display text-2xl font-semibold tracking-tight",
						children: asset.pair
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: asset.name
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-lg font-medium tabular-nums",
						children: formatPrice(snapshot.quote.price, asset.decimals)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: cn("text-xs tabular-nums", snapshot.quote.changePct >= 0 ? "text-call" : "text-put"),
						children: [
							snapshot.quote.changePct >= 0 ? "+" : "",
							snapshot.quote.changePct.toFixed(2).replace(".", ","),
							"%"
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CandleChart, {
					candles: snapshot.candles,
					direction
				})
			}),
			signal?.tradeable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("mt-4 flex items-center gap-4 rounded-xl p-4", call ? "bg-call-dim" : "bg-put-dim"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfidenceRing, {
					value: signal.confidence,
					tone: call ? "call" : "put"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [call ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-5 text-call" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "size-5 text-put" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("font-display text-3xl font-semibold", call ? "text-call" : "text-put"),
								children: call ? "ALTA" : "BAIXA"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted",
							children: [
								call ? "CALL" : "PUT",
								" · ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QualityLabel, { quality: signal.quality }),
								" · entrada",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono tabular-nums",
									children: formatPrice(signal.entryPrice, asset.decimals)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 flex items-center gap-1.5 font-mono text-sm tabular-nums text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5 text-muted" }), countdown.done ? "Renovando…" : countdown.label]
						})
					]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-xl bg-elevated p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg font-medium",
						children: "Sem setup agora"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-relaxed text-muted",
						children: "Indicadores ainda sem confluência suficiente neste candle. O motor só libera entrada quando tendência, momentum e volatilidade se alinham."
					}),
					snapshot.bias ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-xs text-subtle",
						children: [
							"Viés técnico:",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: snapshot.bias.direction === "call" ? "text-call" : "text-put",
								children: snapshot.bias.direction === "call" ? "alta" : "baixa"
							}),
							" ",
							"· força ",
							snapshot.bias.confidence
						]
					}) : null
				]
			}),
			signal?.reasons.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-2",
				children: signal.reasons.map((reason) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "rounded-lg bg-elevated px-3 py-2 text-sm leading-snug text-muted",
					children: reason
				}, reason))
			}) : null,
			snapshot.backtest.sample >= 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-xs text-subtle",
				children: [
					"Acerto recente neste ativo (",
					interval,
					"):",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono tabular-nums text-fg",
						children: [Math.round(snapshot.backtest.hitRate * 100), "%"]
					}),
					" ",
					"em ",
					snapshot.backtest.sample,
					" sinais walk-forward. Passado não garante o próximo candle."
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs text-subtle",
				children: "Amostra de backtest ainda curta neste ativo. O app registra cada sinal e liquida no vencimento."
			})
		]
	});
}
function StatsView() {
	const items = useHistoryStore((s) => s.items);
	const clear = useHistoryStore((s) => s.clear);
	const stats = summarize(items);
	const pct = Math.round(stats.hitRate * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-3 pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "px-1 pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold",
					children: "Desempenho"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Resultados reais das suas sessões neste aparelho."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.16em] text-subtle",
						children: "Taxa de acerto"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-5xl font-semibold tabular-nums tracking-tight",
						children: stats.settled ? `${pct}%` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							stats.wins,
							" wins · ",
							stats.losses,
							" losses · ",
							stats.pending,
							" abertos"
						]
					}),
					stats.streak !== 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm",
						children: [
							"Sequência:",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: stats.streak > 0 ? "text-call" : "text-put",
								children: [
									Math.abs(stats.streak),
									" ",
									stats.streak > 0 ? "wins" : "losses"
								]
							})
						]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-wide text-subtle",
							children: "Melhor ativo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-xl font-semibold",
							children: stats.best ? ASSET_MAP[stats.best.assetId]?.pair : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: stats.best ? `${Math.round(stats.best.hitRate * 100)}% em ${stats.best.n} sinais` : "Mínimo de 3 liquidados"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-wide text-subtle",
							children: "Sinais"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-xl font-semibold tabular-nums",
							children: items.length
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "Registrados nesta sessão"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "mt-0.5 size-4 shrink-0 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs leading-relaxed text-muted",
					children: "A NEXA não promete lucro. Opções de 1 e 5 minutos são especulação de altíssimo risco. Use gestão de banca, nunca opere com dinheiro que não pode perder, e trate cada sinal como análise técnica — não como ordem cega."
				})]
			}),
			items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: clear,
				className: cn("h-11 w-full rounded-xl bg-elevated text-sm text-muted", "transition-transform duration-150 ease-out active:scale-[0.96]"),
				children: "Limpar histórico local"
			}) : null
		]
	});
}
function HeaderClock() {
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setNow(Date.now());
		const id = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-right",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-sm tabular-nums text-fg",
			children: now ? formatTime(now) : "--:--:--"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-center justify-end gap-1.5 text-[10px] uppercase tracking-[0.14em] text-subtle",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-dot size-1.5 rounded-full bg-call" }), "Ao vivo"]
		})]
	});
}
var MARKETS = [
	{
		id: "forex",
		label: "Forex"
	},
	{
		id: "crypto",
		label: "Cripto"
	},
	{
		id: "all",
		label: "Todos"
	}
];
function MarketSwitch() {
	const market = useUiStore((s) => s.market);
	const setMarket = useUiStore((s) => s.setMarket);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-3 gap-1 rounded-xl bg-elevated p-1",
		children: MARKETS.map((item) => {
			const active = market === item.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setMarket(item.id),
				className: cn("h-10 rounded-lg text-sm font-medium transition-colors duration-150", active ? "bg-panel text-fg shadow-[var(--shadow-border)]" : "text-subtle"),
				children: item.label
			}, item.id);
		})
	});
}
function IntervalSwitch() {
	const interval = useUiStore((s) => s.interval);
	const setInterval = useUiStore((s) => s.setInterval);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative grid grid-cols-2 rounded-xl bg-elevated p-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-lg bg-panel shadow-[var(--shadow-border)] transition-transform duration-200 ease-out",
			style: { transform: interval === "5m" ? "translateX(calc(100% + 4px))" : "translateX(4px)" }
		}), ["1m", "5m"].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => setInterval(id),
			className: cn("relative z-10 h-10 text-sm font-medium transition-colors duration-150", interval === id ? "text-fg" : "text-subtle"),
			children: id === "1m" ? "1 minuto" : "5 minutos"
		}, id))]
	});
}
function filterSnapshots(snapshots, market) {
	return snapshots.filter((s) => {
		const asset = ASSET_MAP[s.quote.assetId];
		return asset ? matchesMarket(asset, market) : false;
	});
}
function SignalsBody({ initialFeed }) {
	const interval = useUiStore((s) => s.interval);
	const market = useUiStore((s) => s.market);
	const selectedId = useUiStore((s) => s.selectedId);
	const ingest = useHistoryStore((s) => s.ingest);
	const settle = useHistoryStore((s) => s.settle);
	const query = useQuery({
		queryKey: ["feed", interval],
		queryFn: () => getSignalFeed({ data: { interval } }),
		refetchInterval: 8e3,
		initialData: interval === "1m" ? initialFeed : void 0
	});
	const refetch = query.refetch;
	(0, import_react.useEffect)(() => {
		if (!query.data) return;
		const signals = query.data.snapshots.flatMap((s) => s.signal ? [s.signal] : []);
		ingest(signals);
		settle(query.data.snapshots.map((s) => s.quote), Date.now());
	}, [
		query.data,
		ingest,
		settle
	]);
	const snapshots = (0, import_react.useMemo)(() => query.data ? filterSnapshots(query.data.snapshots, market) : [], [query.data, market]);
	const selected = snapshots.find((s) => s.quote.assetId === selectedId) ?? snapshots.find((s) => s.quote.assetId === "eurusd") ?? snapshots.find((s) => s.signal?.tradeable) ?? snapshots[0];
	const expiryAt = selected?.signal?.expiryAt;
	(0, import_react.useEffect)(() => {
		if (!expiryAt) return;
		const wait = Math.max(800, expiryAt - Date.now() + 700);
		const id = window.setTimeout(() => {
			refetch();
		}, wait);
		return () => window.clearTimeout(id);
	}, [expiryAt, refetch]);
	if (query.isLoading && !query.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 text-sm text-muted",
				children: "Carregando EUR/USD e os pares em dólar…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 rounded-xl bg-elevated" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 rounded-xl bg-elevated" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-80 rounded-2xl bg-surface" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 rounded-xl bg-surface" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 rounded-xl bg-surface" })
		]
	});
	if (query.isError || !query.data || snapshots.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-surface px-4 py-10 text-center shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-lg font-medium",
				children: "Sem cotações agora"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Não foi possível ler EUR/USD e os outros pares em dólar. Tente de novo em alguns segundos."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => query.refetch(),
				className: "mt-5 inline-flex h-11 items-center gap-2 rounded-xl bg-fg px-4 text-sm font-medium text-bg transition-transform duration-150 active:scale-[0.96]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" }), "Tentar novamente"]
			})
		]
	});
	if (!selected) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketSwitch, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntervalSwitch, {})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalHero, {
				snapshot: selected,
				interval
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeedList, {
			snapshots,
			selectedId: selected.quote.assetId
		})
	] });
}
function AssetsPane({ initialFeed }) {
	const interval = useUiStore((s) => s.interval);
	const market = useUiStore((s) => s.market);
	const query = useQuery({
		queryKey: ["feed", interval],
		queryFn: () => getSignalFeed({ data: { interval } }),
		refetchInterval: 8e3,
		initialData: interval === "1m" ? initialFeed : void 0
	});
	if (!query.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2",
		children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 rounded-xl bg-surface" }, i))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketSwitch, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssetsView, { snapshots: filterSnapshots(query.data.snapshots, market) })
	})] });
}
function AppShell({ initialFeed }) {
	const tab = useUiStore((s) => s.tab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex items-center justify-between bg-bg/90 px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-3 backdrop-blur-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-9 items-center justify-center rounded-lg bg-elevated text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg font-semibold leading-none tracking-tight",
						children: "NEXA"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[11px] uppercase tracking-[0.16em] text-subtle",
						children: "EUR/USD ao vivo"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeaderClock, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto w-full max-w-lg px-4 pb-28",
				children: [
					tab === "sinais" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalsBody, { initialFeed }) : null,
					tab === "ativos" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssetsPane, { initialFeed }) : null,
					tab === "historico" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryView, {}) : null,
					tab === "desempenho" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsView, {}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DisclaimerGate, {})
		]
	});
}
function Home() {
	const initialFeed = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { initialFeed });
}
//#endregion
export { Home as component };
