import { r as INTERVAL_MS, t as ASSETS } from "./assets-BKSD5_lQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/feed.server-BONQCnmX.js
function sma(values, period) {
	const out = Array(values.length).fill(null);
	let sum = 0;
	for (let i = 0; i < values.length; i++) {
		sum += values[i];
		if (i >= period) sum -= values[i - period];
		if (i >= period - 1) out[i] = sum / period;
	}
	return out;
}
function ema(values, period) {
	const out = Array(values.length).fill(null);
	if (values.length < period) return out;
	const k = 2 / (period + 1);
	let prev = 0;
	for (let i = 0; i < period; i++) prev += values[i];
	prev /= period;
	out[period - 1] = prev;
	for (let i = period; i < values.length; i++) {
		prev = values[i] * k + prev * (1 - k);
		out[i] = prev;
	}
	return out;
}
function rsi(closes, period = 14) {
	const out = Array(closes.length).fill(null);
	if (closes.length <= period) return out;
	let gain = 0;
	let loss = 0;
	for (let i = 1; i <= period; i++) {
		const diff = closes[i] - closes[i - 1];
		if (diff >= 0) gain += diff;
		else loss -= diff;
	}
	gain /= period;
	loss /= period;
	out[period] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
	for (let i = period + 1; i < closes.length; i++) {
		const diff = closes[i] - closes[i - 1];
		const g = diff > 0 ? diff : 0;
		const l = diff < 0 ? -diff : 0;
		gain = (gain * (period - 1) + g) / period;
		loss = (loss * (period - 1) + l) / period;
		out[i] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
	}
	return out;
}
function stdev(values, period) {
	const out = Array(values.length).fill(null);
	for (let i = period - 1; i < values.length; i++) {
		const slice = values.slice(i - period + 1, i + 1);
		const mean = slice.reduce((a, b) => a + b, 0) / period;
		const variance = slice.reduce((a, b) => a + (b - mean) ** 2, 0) / period;
		out[i] = Math.sqrt(variance);
	}
	return out;
}
function atr(high, low, close, period = 14) {
	const tr = [high[0] - low[0]];
	for (let i = 1; i < close.length; i++) tr.push(Math.max(high[i] - low[i], Math.abs(high[i] - close[i - 1]), Math.abs(low[i] - close[i - 1])));
	return sma(tr, period);
}
function macd(closes, fast = 12, slow = 26, signal = 9) {
	const emaFast = ema(closes, fast);
	const emaSlow = ema(closes, slow);
	const line = closes.map((_, i) => emaFast[i] != null && emaSlow[i] != null ? emaFast[i] - emaSlow[i] : null);
	const compact = line.map((v) => v ?? 0);
	const firstValid = line.findIndex((v) => v != null);
	const signalLine = Array(closes.length).fill(null);
	if (firstValid >= 0) {
		const sig = ema(compact.slice(firstValid), signal);
		for (let i = 0; i < sig.length; i++) if (sig[i] != null) signalLine[firstValid + i] = sig[i];
	}
	return {
		line,
		signal: signalLine,
		hist: line.map((v, i) => v != null && signalLine[i] != null ? v - signalLine[i] : null)
	};
}
function stochastic(high, low, close, period = 14, smooth = 3) {
	const raw = Array(close.length).fill(null);
	for (let i = period - 1; i < close.length; i++) {
		let hh = -Infinity;
		let ll = Infinity;
		for (let j = i - period + 1; j <= i; j++) {
			hh = Math.max(hh, high[j]);
			ll = Math.min(ll, low[j]);
		}
		const range = hh - ll;
		raw[i] = range === 0 ? 50 : (close[i] - ll) / range * 100;
	}
	const kSma = sma(raw.map((v) => v ?? 0), smooth);
	const k = raw.map((v, i) => v == null ? null : kSma[i] ?? v);
	const dSma = sma(k.map((v) => v ?? 0), smooth);
	return {
		k,
		d: k.map((v, i) => v == null ? null : dSma[i] ?? v)
	};
}
function adx(high, low, close, period = 14) {
	const len = close.length;
	const plusDM = [0];
	const minusDM = [0];
	const tr = [high[0] - low[0]];
	for (let i = 1; i < len; i++) {
		const up = high[i] - high[i - 1];
		const down = low[i - 1] - low[i];
		plusDM.push(up > down && up > 0 ? up : 0);
		minusDM.push(down > up && down > 0 ? down : 0);
		tr.push(Math.max(high[i] - low[i], Math.abs(high[i] - close[i - 1]), Math.abs(low[i] - close[i - 1])));
	}
	const smooth = (arr) => {
		const out = Array(len).fill(null);
		if (len <= period) return out;
		let val = 0;
		for (let i = 1; i <= period; i++) val += arr[i];
		out[period] = val;
		for (let i = period + 1; i < len; i++) {
			val = val - val / period + arr[i];
			out[i] = val;
		}
		return out;
	};
	const smTR = smooth(tr);
	const smP = smooth(plusDM);
	const smM = smooth(minusDM);
	const dx = Array(len).fill(null);
	for (let i = 0; i < len; i++) {
		if (smTR[i] == null || smTR[i] === 0 || smP[i] == null || smM[i] == null) continue;
		const plusDI = 100 * smP[i] / smTR[i];
		const minusDI = 100 * smM[i] / smTR[i];
		const den = plusDI + minusDI;
		dx[i] = den === 0 ? 0 : 100 * Math.abs(plusDI - minusDI) / den;
	}
	const out = Array(len).fill(null);
	const start = period * 2;
	if (len <= start) return out;
	let acc = 0;
	let count = 0;
	for (let i = period; i <= start; i++) if (dx[i] != null) {
		acc += dx[i];
		count++;
	}
	if (count === 0) return out;
	let val = acc / count;
	out[start] = val;
	for (let i = start + 1; i < len; i++) {
		if (dx[i] == null) continue;
		val = (val * (period - 1) + dx[i]) / period;
		out[i] = val;
	}
	return out;
}
function lastNumber(arr) {
	for (let i = arr.length - 1; i >= 0; i--) {
		const v = arr[i];
		if (v != null && Number.isFinite(v)) return v;
	}
	return null;
}
function prevNumber(arr) {
	let found = 0;
	for (let i = arr.length - 1; i >= 0; i--) {
		const v = arr[i];
		if (v != null && Number.isFinite(v)) {
			found++;
			if (found === 2) return v;
		}
	}
	return null;
}
var MIN_CANDLES = 55;
function classParams(assetClass) {
	if (assetClass === "forex") return {
		minAtrPct: .0012,
		quietAtrPct: .0028,
		mom: 12e-5
	};
	if (assetClass === "commodity") return {
		minAtrPct: .0035,
		quietAtrPct: .007,
		mom: 35e-5
	};
	return {
		minAtrPct: .008,
		quietAtrPct: .012,
		mom: 8e-4
	};
}
function qualityOf(confidence, agreeing, votes) {
	if (confidence >= 86 && agreeing >= 5) return "elite";
	if (confidence >= 74 && agreeing >= 4) return "strong";
	if (confidence >= 62 && agreeing >= 3) return "medium";
	return "weak";
}
function body(c) {
	return Math.abs(c.close - c.open);
}
function range(c) {
	return Math.max(c.high - c.low, 1e-12);
}
function isBullEngulf(prev, cur) {
	return prev.close < prev.open && cur.close > cur.open && cur.close >= prev.open && cur.open <= prev.close && body(cur) > body(prev) * 1.05;
}
function isBearEngulf(prev, cur) {
	return prev.close > prev.open && cur.close < cur.open && cur.open >= prev.close && cur.close <= prev.open && body(cur) > body(prev) * 1.05;
}
function isPin(c, side) {
	const b = body(c);
	const wickLow = Math.min(c.open, c.close) - c.low;
	const wickHigh = c.high - Math.max(c.open, c.close);
	if (side === "low") return wickLow > b * 2 && wickHigh < b * .8 && b / range(c) < .4;
	return wickHigh > b * 2 && wickLow < b * .8 && b / range(c) < .4;
}
function analyze(candles, assetClass = "crypto") {
	const closed = candles.filter((c) => c.closed);
	if (closed.length < MIN_CANDLES) return null;
	const params = classParams(assetClass);
	const close = closed.map((c) => c.close);
	const high = closed.map((c) => c.high);
	const low = closed.map((c) => c.low);
	const n = closed.length;
	const cur = closed[n - 1];
	const prev = closed[n - 2];
	const prev2 = closed[n - 3];
	const ema8 = ema(close, 8);
	const ema21 = ema(close, 21);
	const ema50 = ema(close, 50);
	const rsi$1 = rsi(close, 14);
	const macdSet = macd(close);
	const stoch = stochastic(high, low, close);
	const mid = sma(close, 20);
	const sd = stdev(close, 20);
	const atr$1 = atr(high, low, close, 14);
	const adxArr = adx(high, low, close, 14);
	const e8 = lastNumber(ema8);
	const e21 = lastNumber(ema21);
	const e50 = lastNumber(ema50);
	const e8p = prevNumber(ema8);
	const e21p = prevNumber(ema21);
	const r = lastNumber(rsi$1);
	const rp = prevNumber(rsi$1);
	const macdH = lastNumber(macdSet.hist);
	const macdHp = prevNumber(macdSet.hist);
	const macdL = lastNumber(macdSet.line);
	const macdS = lastNumber(macdSet.signal);
	const k = lastNumber(stoch.k);
	const d = lastNumber(stoch.d);
	const kp = prevNumber(stoch.k);
	const dp = prevNumber(stoch.d);
	const bbMid = lastNumber(mid);
	const bbSd = lastNumber(sd);
	const atrV = lastNumber(atr$1);
	const adxV = lastNumber(adxArr) ?? 0;
	if (e8 == null || e21 == null || e50 == null || r == null || atrV == null || bbMid == null || bbSd == null) return null;
	const atrPct = atrV / cur.close * 100;
	const regime = adxV >= 22 ? "trend" : "range";
	const votes = [];
	const stackedUp = e8 > e21 && e21 > e50;
	const stackedDown = e8 < e21 && e21 < e50;
	if (stackedUp) votes.push({
		id: "ema-stack",
		label: "Tendência EMA",
		direction: "call",
		weight: 1.4,
		detail: "EMA 8 > 21 > 50 — tendência de alta alinhada"
	});
	else if (stackedDown) votes.push({
		id: "ema-stack",
		label: "Tendência EMA",
		direction: "put",
		weight: 1.4,
		detail: "EMA 8 < 21 < 50 — tendência de baixa alinhada"
	});
	else if (e8 > e21) votes.push({
		id: "ema-stack",
		label: "Tendência EMA",
		direction: "call",
		weight: .6,
		detail: "EMA rápida acima da lenta"
	});
	else votes.push({
		id: "ema-stack",
		label: "Tendência EMA",
		direction: "put",
		weight: .6,
		detail: "EMA rápida abaixo da lenta"
	});
	if (e8p != null && e21p != null) {
		if (e8p <= e21p && e8 > e21) votes.push({
			id: "ema-cross",
			label: "Cruzamento EMA",
			direction: "call",
			weight: 1.3,
			detail: "Cruzamento de alta da EMA 8 × 21"
		});
		else if (e8p >= e21p && e8 < e21) votes.push({
			id: "ema-cross",
			label: "Cruzamento EMA",
			direction: "put",
			weight: 1.3,
			detail: "Cruzamento de baixa da EMA 8 × 21"
		});
	}
	if (regime === "range") {
		if (r <= 32 && (rp == null || r > rp)) votes.push({
			id: "rsi",
			label: "RSI",
			direction: "call",
			weight: 1.35,
			detail: `RSI ${r.toFixed(1)} em sobrevenda com reversão`
		});
		else if (r >= 68 && (rp == null || r < rp)) votes.push({
			id: "rsi",
			label: "RSI",
			direction: "put",
			weight: 1.35,
			detail: `RSI ${r.toFixed(1)} em sobrecompra com reversão`
		});
		else votes.push({
			id: "rsi",
			label: "RSI",
			direction: "neutral",
			weight: .2,
			detail: `RSI ${r.toFixed(1)} neutro no range`
		});
	} else if (r >= 54) votes.push({
		id: "rsi",
		label: "RSI",
		direction: "call",
		weight: r >= 62 ? 1.1 : .7,
		detail: `RSI ${r.toFixed(1)} confirma momentum de alta`
	});
	else if (r <= 46) votes.push({
		id: "rsi",
		label: "RSI",
		direction: "put",
		weight: r <= 38 ? 1.1 : .7,
		detail: `RSI ${r.toFixed(1)} confirma momentum de baixa`
	});
	if (macdH != null && macdHp != null) {
		if (macdL != null && macdS != null && macdL > macdS && macdHp <= 0 && macdH > 0) votes.push({
			id: "macd",
			label: "MACD",
			direction: "call",
			weight: 1.4,
			detail: "MACD cruzou acima da sinal com histograma positivo"
		});
		else if (macdL != null && macdS != null && macdL < macdS && macdHp >= 0 && macdH < 0) votes.push({
			id: "macd",
			label: "MACD",
			direction: "put",
			weight: 1.4,
			detail: "MACD cruzou abaixo da sinal com histograma negativo"
		});
		else if (macdH > 0 && macdH > macdHp) votes.push({
			id: "macd",
			label: "MACD",
			direction: "call",
			weight: 1,
			detail: "Histograma MACD acelerando para cima"
		});
		else if (macdH < 0 && macdH < macdHp) votes.push({
			id: "macd",
			label: "MACD",
			direction: "put",
			weight: 1,
			detail: "Histograma MACD acelerando para baixo"
		});
	}
	if (k != null && d != null) {
		if (kp != null && dp != null && kp < dp && k > d && k < 30) votes.push({
			id: "stoch",
			label: "Estocástico",
			direction: "call",
			weight: 1.25,
			detail: `Estocástico cruzou no suporte (${k.toFixed(0)})`
		});
		else if (kp != null && dp != null && kp > dp && k < d && k > 70) votes.push({
			id: "stoch",
			label: "Estocástico",
			direction: "put",
			weight: 1.25,
			detail: `Estocástico cruzou na resistência (${k.toFixed(0)})`
		});
		else if (k < 22) votes.push({
			id: "stoch",
			label: "Estocástico",
			direction: "call",
			weight: .7,
			detail: "Estocástico em sobrevenda"
		});
		else if (k > 78) votes.push({
			id: "stoch",
			label: "Estocástico",
			direction: "put",
			weight: .7,
			detail: "Estocástico em sobrecompra"
		});
	}
	const upper = bbMid + 2 * bbSd;
	const lower = bbMid - 2 * bbSd;
	if (cur.close <= lower && r < 40) votes.push({
		id: "bb",
		label: "Bollinger",
		direction: "call",
		weight: 1.3,
		detail: "Preço na banda inferior com RSI baixo"
	});
	else if (cur.close >= upper && r > 60) votes.push({
		id: "bb",
		label: "Bollinger",
		direction: "put",
		weight: 1.3,
		detail: "Preço na banda superior com RSI alto"
	});
	else if (regime === "trend" && cur.close > bbMid && stackedUp) votes.push({
		id: "bb",
		label: "Bollinger",
		direction: "call",
		weight: .6,
		detail: "Preço acima da média das bandas, tendência de alta"
	});
	else if (regime === "trend" && cur.close < bbMid && stackedDown) votes.push({
		id: "bb",
		label: "Bollinger",
		direction: "put",
		weight: .6,
		detail: "Preço abaixo da média das bandas, tendência de baixa"
	});
	if (isBullEngulf(prev, cur) || isPin(cur, "low")) votes.push({
		id: "candle",
		label: "Candle",
		direction: "call",
		weight: 1.2,
		detail: isBullEngulf(prev, cur) ? "Engolfo de alta" : "Pavio inferior (pin bar de alta)"
	});
	else if (isBearEngulf(prev, cur) || isPin(cur, "high")) votes.push({
		id: "candle",
		label: "Candle",
		direction: "put",
		weight: 1.2,
		detail: isBearEngulf(prev, cur) ? "Engolfo de baixa" : "Pavio superior (pin bar de baixa)"
	});
	else if (cur.close > cur.open && prev.close > prev.open && prev2.close > prev2.open) votes.push({
		id: "candle",
		label: "Candle",
		direction: "call",
		weight: .8,
		detail: "Três candles consecutivos de alta"
	});
	else if (cur.close < cur.open && prev.close < prev.open && prev2.close < prev2.open) votes.push({
		id: "candle",
		label: "Candle",
		direction: "put",
		weight: .8,
		detail: "Três candles consecutivos de baixa"
	});
	const mom = (cur.close - closed[n - 4].close) / closed[n - 4].close;
	if (mom > params.mom) votes.push({
		id: "mom",
		label: "Momentum",
		direction: "call",
		weight: .7,
		detail: "Impulso de alta nas últimas velas"
	});
	else if (mom < -params.mom) votes.push({
		id: "mom",
		label: "Momentum",
		direction: "put",
		weight: .7,
		detail: "Impulso de baixa nas últimas velas"
	});
	if (adxV >= 25 && stackedUp) votes.push({
		id: "adx",
		label: "ADX",
		direction: "call",
		weight: .9,
		detail: `ADX ${adxV.toFixed(1)} — tendência de alta forte`
	});
	else if (adxV >= 25 && stackedDown) votes.push({
		id: "adx",
		label: "ADX",
		direction: "put",
		weight: .9,
		detail: `ADX ${adxV.toFixed(1)} — tendência de baixa forte`
	});
	const directed = votes.filter((v) => v.direction !== "neutral");
	const callScore = directed.filter((v) => v.direction === "call").reduce((s, v) => s + v.weight, 0);
	const putScore = directed.filter((v) => v.direction === "put").reduce((s, v) => s + v.weight, 0);
	const total = callScore + putScore;
	if (total <= 0) return null;
	const direction = callScore >= putScore ? "call" : "put";
	const dominance = ((direction === "call" ? callScore : putScore) - (direction === "call" ? putScore : callScore)) / total;
	const agreeing = directed.filter((v) => v.direction === direction).length;
	const coverage = agreeing / Math.max(directed.length, 1);
	let confidence = Math.round(52 + dominance * 38 + coverage * 10);
	if (atrPct < params.quietAtrPct) confidence -= 8;
	if (regime === "trend" && adxV >= 28) confidence += 3;
	confidence = Math.max(50, Math.min(94, confidence));
	if (atrPct < params.minAtrPct) confidence = Math.min(confidence, 60);
	const quality = qualityOf(confidence, agreeing, directed.length);
	const tradeable = quality !== "weak" && dominance >= .18 && atrPct >= params.minAtrPct;
	const reasons = directed.filter((v) => v.direction === direction).sort((a, b) => b.weight - a.weight).slice(0, 4).map((v) => v.detail);
	return {
		direction,
		confidence,
		quality,
		tradeable,
		votes,
		agreeing,
		reasons,
		regime,
		adx: adxV,
		rsi: r,
		atrPct,
		emaFast: e8,
		emaSlow: e21
	};
}
function toLiveSignal(assetId, interval, candles, analysis, now) {
	const closed = candles.filter((c) => c.closed);
	const last = closed[closed.length - 1];
	const ms = INTERVAL_MS[interval];
	const issuedAt = last.time + ms;
	const expiryAt = issuedAt + ms;
	return {
		assetId,
		interval,
		direction: analysis.direction,
		confidence: analysis.confidence,
		quality: analysis.quality,
		tradeable: analysis.tradeable,
		reasons: analysis.reasons,
		votes: analysis.votes,
		regime: analysis.regime,
		rsi: analysis.rsi,
		adx: analysis.adx,
		atrPct: analysis.atrPct,
		entryPrice: last.close,
		issuedAt,
		expiryAt,
		serverNow: now
	};
}
var UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36";
var mem = /* @__PURE__ */ new Map();
function cached(key, ttl, fn) {
	const hit = mem.get(key);
	if (hit && Date.now() - hit.at < ttl) return Promise.resolve(hit.value);
	return fn().then((value) => {
		mem.set(key, {
			at: Date.now(),
			value
		});
		return value;
	});
}
async function fetchJson(url, timeoutMs = 9e3) {
	const ctrl = new AbortController();
	const t = setTimeout(() => ctrl.abort(), timeoutMs);
	try {
		const res = await fetch(url, {
			headers: {
				"user-agent": UA,
				accept: "application/json"
			},
			signal: ctrl.signal
		});
		if (!res.ok) throw new Error(`HTTP ${res.status}`);
		return await res.json();
	} finally {
		clearTimeout(t);
	}
}
function intervalMs(interval) {
	return INTERVAL_MS[interval];
}
function markClosed(candles, interval, now) {
	const ms = intervalMs(interval);
	return candles.filter((c) => Number.isFinite(c.close) && c.close > 0).map((c) => ({
		...c,
		closed: c.time + ms <= now + 1500
	}));
}
function fromOkx(raw, interval, now) {
	const data = raw.data;
	if (!Array.isArray(data)) return [];
	return markClosed(data.map((row) => ({
		time: Number(row[0]),
		open: Number(row[1]),
		high: Number(row[2]),
		low: Number(row[3]),
		close: Number(row[4]),
		volume: Number(row[5] ?? 0),
		closed: row[row.length - 1] === "1"
	})).reverse(), interval, now);
}
function fromYahoo(raw, interval, now) {
	const result = raw.chart?.result?.[0];
	if (!result) return [];
	const ts = result.timestamp ?? [];
	const quote = result.indicators?.quote?.[0];
	if (!quote) return [];
	const candles = [];
	for (let i = 0; i < ts.length; i++) {
		const open = quote.open?.[i];
		const high = quote.high?.[i];
		const low = quote.low?.[i];
		const close = quote.close?.[i];
		const volume = quote.volume?.[i];
		if (open == null || high == null || low == null || close == null) continue;
		candles.push({
			time: ts[i] * 1e3,
			open,
			high,
			low,
			close,
			volume: volume ?? 0,
			closed: true
		});
	}
	return markClosed(candles, interval, now);
}
function fromCoinbase(raw, interval, now) {
	if (!Array.isArray(raw)) return [];
	return markClosed(raw.map((row) => ({
		time: Number(row[0]) * 1e3,
		low: Number(row[1]),
		high: Number(row[2]),
		open: Number(row[3]),
		close: Number(row[4]),
		volume: Number(row[5]),
		closed: true
	})).sort((a, b) => a.time - b.time), interval, now);
}
function fromBiquote(raw, interval, now) {
	const bars = raw.bars;
	if (!Array.isArray(bars)) return [];
	return markClosed(bars.map((b) => {
		return {
			time: Date.parse(String(b.openTime ?? "")),
			open: Number(b.open),
			high: Number(b.high),
			low: Number(b.low),
			close: Number(b.close),
			volume: Number(b.tickVolume ?? b.volume ?? 0),
			closed: b.isOpen !== true
		};
	}).filter((c) => Number.isFinite(c.time) && c.time > 0).sort((a, b) => a.time - b.time), interval, now);
}
function fromTwelve(raw, interval, now) {
	const values = raw.values;
	if (!Array.isArray(values)) return [];
	return markClosed(values.map((row) => {
		const stamp = String(row.datetime ?? "").replace(" ", "T");
		return {
			time: Date.parse(stamp.endsWith("Z") ? stamp : `${stamp}Z`),
			open: Number(row.open),
			high: Number(row.high),
			low: Number(row.low),
			close: Number(row.close),
			volume: Number(row.volume ?? 0),
			closed: true
		};
	}).filter((c) => Number.isFinite(c.time) && c.time > 0).sort((a, b) => a.time - b.time), interval, now);
}
async function fetchOkx(instId, interval, now) {
	return fromOkx(await fetchJson(`https://www.okx.com/api/v5/market/candles?instId=${encodeURIComponent(instId)}&bar=${interval === "1m" ? "1m" : "5m"}&limit=120`), interval, now);
}
async function fetchOkxIndex(instId, interval, now) {
	return fromOkx(await fetchJson(`https://www.okx.com/api/v5/market/index-candles?instId=${encodeURIComponent(instId)}&bar=${interval === "1m" ? "1m" : "5m"}&limit=120`), interval, now);
}
async function fetchCoinbase(product, interval, now) {
	return fromCoinbase(await fetchJson(`https://api.exchange.coinbase.com/products/${encodeURIComponent(product)}/candles?granularity=${interval === "1m" ? 60 : 300}`), interval, now);
}
async function fetchYahoo(ticker, interval, now) {
	const range = interval === "1m" ? "1d" : "5d";
	const hosts = ["query1.finance.yahoo.com", "query2.finance.yahoo.com"];
	let lastErr;
	for (const host of hosts) {
		const url = `https://${host}/v8/finance/chart/${encodeURIComponent(ticker)}?interval=${interval}&range=${range}&includePrePost=false`;
		try {
			return fromYahoo(await fetchJson(url), interval, now);
		} catch (err) {
			lastErr = err;
		}
	}
	throw lastErr instanceof Error ? lastErr : /* @__PURE__ */ new Error("Yahoo falhou");
}
async function fetchBiquote(symbol, interval, now) {
	return fromBiquote(await fetchJson(`https://biquote.io/api/${encodeURIComponent(symbol)}/ohlc?interval=${interval}&limit=120`), interval, now);
}
async function fetchTwelve(symbol, interval, now) {
	return fromTwelve(await fetchJson(`https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(symbol)}&interval=${interval === "1m" ? "1min" : "5min"}&outputsize=120&apikey=demo`), interval, now);
}
function fallbackFetcher(source, interval, now) {
	if (source.kind === "twelve") return fetchTwelve(source.symbol, interval, now);
	if (source.kind === "okx-index") return fetchOkxIndex(source.instId, interval, now);
	if (source.kind === "coinbase") return fetchCoinbase(source.product, interval, now);
	if (source.kind === "okx") return fetchOkx(source.instId, interval, now);
	return fetchYahoo(source.ticker, interval, now);
}
async function loadCandles(asset, interval, now) {
	return cached(`candles:${asset.id}:${interval}`, 7e3, async () => {
		const attempts = [() => fetchBiquote(asset.biquote, interval, now), ...(asset.fallbacks ?? []).map((source) => () => fallbackFetcher(source, interval, now))];
		let lastErr;
		for (const run of attempts) try {
			const rows = await run();
			if (rows.length >= 50) return rows;
			lastErr = /* @__PURE__ */ new Error("poucos candles");
		} catch (err) {
			lastErr = err;
		}
		throw lastErr instanceof Error ? lastErr : /* @__PURE__ */ new Error("sem candles");
	});
}
function toQuote(assetId, candles) {
	const last = candles[candles.length - 1];
	const lookback = Math.min(candles.length - 1, intervalLookback(candles));
	const prev = candles[candles.length - 1 - lookback] ?? candles[0];
	const changePct = prev.close ? (last.close - prev.close) / prev.close * 100 : 0;
	const spark = candles.slice(-28).map((c) => c.close);
	return {
		assetId,
		price: last.close,
		changePct,
		spark
	};
}
function intervalLookback(candles) {
	if (candles.length < 3) return 1;
	if (candles[candles.length - 1].time - candles[candles.length - 2].time <= 7e4) return Math.min(1440, candles.length - 1);
	return Math.min(288, candles.length - 1);
}
async function buildFeed(interval) {
	return cached(`feed:${interval}`, 6e3, async () => {
		const now = Date.now();
		const snapshots = (await Promise.allSettled(ASSETS.map(async (asset) => {
			const candles = await loadCandles(asset, interval, now);
			if (candles.length < 30) throw new Error("poucos candles");
			const analysis = analyze(candles, asset.class);
			const signal = analysis ? toLiveSignal(asset.id, interval, candles, analysis, now) : null;
			return {
				quote: toQuote(asset.id, candles),
				candles: candles.slice(-80),
				signal,
				bias: analysis ? {
					direction: analysis.direction,
					confidence: analysis.confidence
				} : null,
				backtest: {
					sample: 0,
					wins: 0,
					losses: 0,
					hitRate: 0
				}
			};
		}))).flatMap((r) => r.status === "fulfilled" ? [r.value] : []);
		snapshots.sort((a, b) => {
			const rank = (id) => id === "eurusd" ? 1 : 0;
			const as = a.signal?.tradeable ? a.signal.confidence : (a.bias?.confidence ?? 0) * .4;
			const bs = b.signal?.tradeable ? b.signal.confidence : (b.bias?.confidence ?? 0) * .4;
			return rank(b.quote.assetId) - rank(a.quote.assetId) || bs - as;
		});
		return {
			interval,
			serverNow: now,
			snapshots
		};
	});
}
//#endregion
export { buildFeed };
