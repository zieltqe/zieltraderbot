import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-CVFKiDQo.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var intervalSchema = _enum(["1m", "5m"]);
var getSignalFeed_createServerFn_handler = createServerRpc({
	id: "c37aa26f933743d872324f3480c56a254c3432542a0594231722b11cb584dedd",
	name: "getSignalFeed",
	filename: "src/lib/market/api.ts"
}, (opts) => getSignalFeed.__executeServer(opts));
var getSignalFeed = createServerFn({ method: "POST" }).validator((input) => ({ interval: intervalSchema.parse(input.interval) })).handler(getSignalFeed_createServerFn_handler, async ({ data }) => {
	const { buildFeed } = await import("./feed.server-BONQCnmX.mjs");
	return buildFeed(data.interval);
});
//#endregion
export { getSignalFeed_createServerFn_handler };
