import type { Candle, Direction } from "@/lib/market/types";
import { cn } from "@/lib/utils";

export function CandleChart({
  candles,
  direction,
  className,
}: {
  candles: Candle[];
  direction?: Direction | null;
  className?: string;
}) {
  const slice = candles.slice(-40);
  if (slice.length < 4) {
    return <div className={cn("h-36 rounded-xl bg-elevated", className)} />;
  }

  const min = Math.min(...slice.map((c) => c.low));
  const max = Math.max(...slice.map((c) => c.high));
  const pad = (max - min) * 0.08 || 1;
  const lo = min - pad;
  const hi = max + pad;
  const w = 320;
  const h = 140;
  const gap = 1.4;
  const cw = (w - gap * slice.length) / slice.length;

  const y = (price: number) => ((hi - price) / (hi - lo)) * h;
  const last = slice[slice.length - 1]!;
  const lastY = y(last.close);

  return (
    <svg
      viewBox={`0 0 ${w} ${h}`}
      className={cn("h-36 w-full overflow-visible", className)}
      role="img"
      aria-label="Gráfico de velas"
    >
      <line
        x1="0"
        x2={w}
        y1={lastY}
        y2={lastY}
        className="stroke-border"
        strokeDasharray="3 4"
        strokeWidth="1"
      />
      {slice.map((c, i) => {
        const x = i * (cw + gap);
        const up = c.close >= c.open;
        const top = y(Math.max(c.open, c.close));
        const bot = y(Math.min(c.open, c.close));
        const body = Math.max(bot - top, 1.2);
        const forming = !c.closed && i === slice.length - 1;
        return (
          <g key={c.time} className={up ? "text-call" : "text-put"} opacity={forming ? 0.55 : 1}>
            <line
              x1={x + cw / 2}
              x2={x + cw / 2}
              y1={y(c.high)}
              y2={y(c.low)}
              stroke="currentColor"
              strokeWidth="1"
            />
            <rect
              x={x}
              y={top}
              width={cw}
              height={body}
              rx="0.6"
              fill="currentColor"
            />
          </g>
        );
      })}
      {direction ? (
        <circle
          cx={w - cw / 2}
          cy={lastY}
          r="2.4"
          className={direction === "call" ? "fill-call" : "fill-put"}
        />
      ) : null}
    </svg>
  );
}

export function Sparkline({ values, up }: { values: number[]; up: boolean }) {
  if (values.length < 2) return <div className="h-8 w-16" />;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const d = values
    .map((v, i) => {
      const x = (i / (values.length - 1)) * 64;
      const y = 18 - ((v - min) / span) * 16;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <svg viewBox="0 0 64 20" className="h-8 w-16" aria-hidden="true">
      <path
        d={d}
        fill="none"
        className={up ? "stroke-call" : "stroke-put"}
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
