import { ASSET_MAP } from "@/lib/market/assets";
import type { AssetSnapshot } from "@/lib/market/types";
import { useUiStore } from "@/lib/store";
import { cn, formatPrice } from "@/lib/utils";
import { Sparkline } from "@/components/candle-chart";

const CLASS_LABEL = {
  forex: "Forex",
  crypto: "Cripto",
  commodity: "Ouro",
} as const;

export function AssetsView({ snapshots }: { snapshots: AssetSnapshot[] }) {
  const setSelectedId = useUiStore((s) => s.setSelectedId);

  return (
    <div className="stagger-in space-y-2 pb-4">
      <header className="px-1 pb-2">
        <h2 className="font-display text-2xl font-semibold">Ativos</h2>
        <p className="mt-1 text-sm text-muted">
          Cotações reais em USD. Toque para abrir o sinal de EUR/USD ou outro par.
        </p>
      </header>
      {snapshots.map((snap) => {
        const asset = ASSET_MAP[snap.quote.assetId];
        if (!asset) return null;
        const up = snap.quote.changePct >= 0;
        const live = Boolean(snap.signal?.tradeable);
        return (
          <button
            key={asset.id}
            type="button"
            onClick={() => setSelectedId(asset.id)}
            className="flex w-full items-center gap-3 rounded-xl bg-surface px-3 py-3 text-left shadow-[var(--shadow-border)] transition-transform duration-150 ease-out active:scale-[0.98]"
          >
            <span className="min-w-0 flex-1">
              <span className="flex items-center gap-2">
                <span className="font-medium">{asset.pair}</span>
                <span className="text-[10px] uppercase tracking-wide text-subtle">
                  {CLASS_LABEL[asset.class]}
                </span>
              </span>
              <span className="mt-0.5 block text-xs text-muted">{asset.name}</span>
            </span>
            <Sparkline values={snap.quote.spark} up={up} />
            <span className="w-24 text-right">
              <span className="block font-mono text-sm tabular-nums">
                {formatPrice(snap.quote.price, asset.decimals)}
              </span>
              <span className={cn("text-xs tabular-nums", up ? "text-call" : "text-put")}>
                {up ? "+" : ""}
                {snap.quote.changePct.toFixed(2).replace(".", ",")}%
              </span>
              {live ? (
                <span className="mt-1 block text-[10px] uppercase tracking-wide text-accent">
                  Sinal ativo
                </span>
              ) : null}
            </span>
          </button>
        );
      })}
    </div>
  );
}
