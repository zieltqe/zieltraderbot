import { Activity, BarChart3, History, Radio } from "lucide-react";
import { cn } from "@/lib/utils";
import { useUiStore, type TabId } from "@/lib/store";

const TABS: { id: TabId; label: string; icon: typeof Radio }[] = [
  { id: "sinais", label: "Sinais", icon: Radio },
  { id: "ativos", label: "Ativos", icon: Activity },
  { id: "historico", label: "Histórico", icon: History },
  { id: "desempenho", label: "Desempenho", icon: BarChart3 },
];

export function BottomNav() {
  const tab = useUiStore((s) => s.tab);
  const setTab = useUiStore((s) => s.setTab);

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm"
      aria-label="Navegação principal"
    >
      <ul className="mx-auto grid max-w-lg grid-cols-4">
        {TABS.map((item) => {
          const active = tab === item.id;
          const Icon = item.icon;
          return (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => setTab(item.id)}
                className={cn(
                  "flex h-16 w-full flex-col items-center justify-center gap-1 text-[11px] font-medium tracking-wide transition-colors duration-150",
                  active ? "text-fg" : "text-subtle",
                )}
                aria-current={active ? "page" : undefined}
              >
                <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
                {item.label}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
