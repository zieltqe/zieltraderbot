import { ChevronRight, TrendingDown, TrendingUp } from "lucide-react";
import { ASSET_MAP } from "@/lib/market/assets";
import type { AssetSnapshot } from "@/lib/market/types";
import { useUiStore } from "@/lib/store";
import { cn, formatPrice } from "@/lib/utils";

export function FeedList({
  snapshots,
  selectedId,
}: {
  snapshots: AssetSnapshot[];
  selectedId: string;
}) {
  const setSelectedId = useUiStore((s) => s.setSelectedId);
  const others = snapshots.filter((s) => s.quote.assetId !== selectedId);

  if (!others.length) return null;

  return (
    <section className="mt-5">
      <h3 className="px-1 text-[11px] font-medium uppercase tracking-[0.16em] text-subtle">
        Outros ativos
      </h3>
      <ul className="mt-2 space-y-2">
        {others.map((snap) => {
          const asset = ASSET_MAP[snap.quote.assetId];
          if (!asset) return null;
          const signal = snap.signal;
          const call = (signal?.direction ?? snap.bias?.direction) === "call";
          const live = Boolean(signal?.tradeable);
          return (
            <li key={asset.id}>
              <button
                type="button"
                onClick={() => setSelectedId(asset.id)}
                className="flex w-full items-center gap-3 rounded-xl bg-surface px-3 py-3 text-left shadow-[var(--shadow-border)] transition-transform duration-150 ease-out active:scale-[0.98]"
              >
                <span
                  className={cn(
                    "flex size-9 items-center justify-center rounded-lg",
                    live ? (call ? "bg-call-dim text-call" : "bg-put-dim text-put") : "bg-elevated text-muted",
                  )}
                >
                  {call ? <TrendingUp className="size-4" /> : <TrendingDown className="size-4" />}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-2">
                    <span className="font-medium">{asset.pair}</span>
                    {live ? (
                      <span
                        className={cn(
                          "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                          call ? "bg-call-dim text-call" : "bg-put-dim text-put",
                        )}
                      >
                        {call ? "Alta" : "Baixa"} {signal?.confidence}
                      </span>
                    ) : (
                      <span className="text-[10px] uppercase tracking-wide text-subtle">Aguardar</span>
                    )}
                  </span>
                  <span className="block font-mono text-xs tabular-nums text-muted">
                    {formatPrice(snap.quote.price, asset.decimals)}
                  </span>
                </span>
                <ChevronRight className="size-4 text-subtle" />
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
