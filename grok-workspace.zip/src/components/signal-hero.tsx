import { useEffect, useState } from "react";
import { Clock, TrendingDown, TrendingUp } from "lucide-react";
import { ASSET_MAP } from "@/lib/market/assets";
import type { AssetSnapshot, Interval, LiveSignal } from "@/lib/market/types";
import { cn, formatPrice, pad2 } from "@/lib/utils";
import { CandleChart } from "@/components/candle-chart";

function useCountdown(expiryAt: number, serverNow: number) {
  const [left, setLeft] = useState<number | null>(null);
  useEffect(() => {
    const skew = Date.now() - serverNow;
    const tick = () => setLeft(Math.max(0, expiryAt - (Date.now() - skew)));
    tick();
    const id = window.setInterval(tick, 200);
    return () => window.clearInterval(id);
  }, [expiryAt, serverNow]);
  if (left == null) return { left: 0, label: "--:--", done: false };
  const sec = Math.floor(left / 1000);
  return { left, label: `${pad2(Math.floor(sec / 60))}:${pad2(sec % 60)}`, done: left <= 0 };
}

function QualityLabel({ quality }: { quality: LiveSignal["quality"] }) {
  const map = {
    elite: "Elite",
    strong: "Forte",
    medium: "Médio",
    weak: "Fraco",
  };
  return <span>{map[quality]}</span>;
}

function ConfidenceRing({
  value,
  tone,
}: {
  value: number;
  tone: "call" | "put" | "muted";
}) {
  const r = 28;
  const c = 2 * Math.PI * r;
  const offset = c - (value / 100) * c;
  const stroke =
    tone === "call" ? "stroke-call" : tone === "put" ? "stroke-put" : "stroke-muted";
  return (
    <div className="relative size-20">
      <svg viewBox="0 0 72 72" className="size-20 -rotate-90">
        <circle cx="36" cy="36" r={r} className="stroke-border" strokeWidth="5" fill="none" />
        <circle
          cx="36"
          cy="36"
          r={r}
          className={stroke}
          strokeWidth="5"
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-mono text-lg font-medium tabular-nums leading-none">{value}</span>
        <span className="text-[9px] uppercase tracking-wider text-subtle">força</span>
      </div>
    </div>
  );
}

export function SignalHero({
  snapshot,
  interval,
}: {
  snapshot: AssetSnapshot;
  interval: Interval;
}) {
  const asset = ASSET_MAP[snapshot.quote.assetId];
  const signal = snapshot.signal;
  const direction = signal?.direction ?? snapshot.bias?.direction ?? null;
  const call = direction === "call";
  const countdown = useCountdown(
    signal?.expiryAt ?? Date.now(),
    signal?.serverNow ?? Date.now(),
  );

  if (!asset) return null;

  return (
    <section className="rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-subtle">
            {interval === "1m" ? "Expiração 1 minuto" : "Expiração 5 minutos"}
          </p>
          <h2 className="mt-1 font-display text-2xl font-semibold tracking-tight">{asset.pair}</h2>
          <p className="text-sm text-muted">{asset.name}</p>
        </div>
        <div className="text-right">
          <p className="font-mono text-lg font-medium tabular-nums">
            {formatPrice(snapshot.quote.price, asset.decimals)}
          </p>
          <p
            className={cn(
              "text-xs tabular-nums",
              snapshot.quote.changePct >= 0 ? "text-call" : "text-put",
            )}
          >
            {snapshot.quote.changePct >= 0 ? "+" : ""}
            {snapshot.quote.changePct.toFixed(2).replace(".", ",")}%
          </p>
        </div>
      </div>

      <div className="mt-4">
        <CandleChart candles={snapshot.candles} direction={direction} />
      </div>

      {signal?.tradeable ? (
        <div
          className={cn(
            "mt-4 flex items-center gap-4 rounded-xl p-4",
            call ? "bg-call-dim" : "bg-put-dim",
          )}
        >
          <ConfidenceRing value={signal.confidence} tone={call ? "call" : "put"} />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              {call ? (
                <TrendingUp className="size-5 text-call" />
              ) : (
                <TrendingDown className="size-5 text-put" />
              )}
              <p className={cn("font-display text-3xl font-semibold", call ? "text-call" : "text-put")}>
                {call ? "ALTA" : "BAIXA"}
              </p>
            </div>
            <p className="mt-1 text-xs text-muted">
              {call ? "CALL" : "PUT"} · <QualityLabel quality={signal.quality} /> · entrada{" "}
              <span className="font-mono tabular-nums">
                {formatPrice(signal.entryPrice, asset.decimals)}
              </span>
            </p>
            <p className="mt-2 flex items-center gap-1.5 font-mono text-sm tabular-nums text-fg">
              <Clock className="size-3.5 text-muted" />
              {countdown.done ? "Renovando…" : countdown.label}
            </p>
          </div>
        </div>
      ) : (
        <div className="mt-4 rounded-xl bg-elevated p-4">
          <p className="font-display text-lg font-medium">Sem setup agora</p>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            Indicadores ainda sem confluência suficiente neste candle. O motor só libera
            entrada quando tendência, momentum e volatilidade se alinham.
          </p>
          {snapshot.bias ? (
            <p className="mt-3 text-xs text-subtle">
              Viés técnico:{" "}
              <span className={snapshot.bias.direction === "call" ? "text-call" : "text-put"}>
                {snapshot.bias.direction === "call" ? "alta" : "baixa"}
              </span>{" "}
              · força {snapshot.bias.confidence}
            </p>
          ) : null}
        </div>
      )}

      {signal?.reasons.length ? (
        <ul className="mt-4 space-y-2">
          {signal.reasons.map((reason) => (
            <li
              key={reason}
              className="rounded-lg bg-elevated px-3 py-2 text-sm leading-snug text-muted"
            >
              {reason}
            </li>
          ))}
        </ul>
      ) : null}

      {snapshot.backtest.sample >= 6 ? (
        <p className="mt-4 text-xs text-subtle">
          Acerto recente neste ativo ({interval}):{" "}
          <span className="font-mono tabular-nums text-fg">
            {Math.round(snapshot.backtest.hitRate * 100)}%
          </span>{" "}
          em {snapshot.backtest.sample} sinais walk-forward. Passado não garante o próximo candle.
        </p>
      ) : (
        <p className="mt-4 text-xs text-subtle">
          Amostra de backtest ainda curta neste ativo. O app registra cada sinal e liquida no
          vencimento.
        </p>
      )}
    </section>
  );
}
