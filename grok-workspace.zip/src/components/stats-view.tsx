import { ShieldAlert } from "lucide-react";
import { ASSET_MAP } from "@/lib/market/assets";
import { summarize, useHistoryStore } from "@/lib/history";
import { cn } from "@/lib/utils";

export function StatsView() {
  const items = useHistoryStore((s) => s.items);
  const clear = useHistoryStore((s) => s.clear);
  const stats = summarize(items);
  const pct = Math.round(stats.hitRate * 100);

  return (
    <div className="stagger-in space-y-3 pb-4">
      <header className="px-1 pb-1">
        <h2 className="font-display text-2xl font-semibold">Desempenho</h2>
        <p className="mt-1 text-sm text-muted">Resultados reais das suas sessões neste aparelho.</p>
      </header>

      <div className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
        <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-subtle">Taxa de acerto</p>
        <p className="mt-2 font-display text-5xl font-semibold tabular-nums tracking-tight">
          {stats.settled ? `${pct}%` : "—"}
        </p>
        <p className="mt-2 text-sm text-muted">
          {stats.wins} wins · {stats.losses} losses · {stats.pending} abertos
        </p>
        {stats.streak !== 0 ? (
          <p className="mt-3 text-sm">
            Sequência:{" "}
            <span className={stats.streak > 0 ? "text-call" : "text-put"}>
              {Math.abs(stats.streak)} {stats.streak > 0 ? "wins" : "losses"}
            </span>
          </p>
        ) : null}
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <p className="text-[11px] uppercase tracking-wide text-subtle">Melhor ativo</p>
          <p className="mt-2 font-display text-xl font-semibold">
            {stats.best ? ASSET_MAP[stats.best.assetId]?.pair : "—"}
          </p>
          <p className="mt-1 text-xs text-muted">
            {stats.best
              ? `${Math.round(stats.best.hitRate * 100)}% em ${stats.best.n} sinais`
              : "Mínimo de 3 liquidados"}
          </p>
        </div>
        <div className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <p className="text-[11px] uppercase tracking-wide text-subtle">Sinais</p>
          <p className="mt-2 font-display text-xl font-semibold tabular-nums">{items.length}</p>
          <p className="mt-1 text-xs text-muted">Registrados nesta sessão</p>
        </div>
      </div>

      <div className="flex gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <ShieldAlert className="mt-0.5 size-4 shrink-0 text-accent" />
        <p className="text-xs leading-relaxed text-muted">
          A NEXA não promete lucro. Opções de 1 e 5 minutos são especulação de altíssimo risco.
          Use gestão de banca, nunca opere com dinheiro que não pode perder, e trate cada sinal
          como análise técnica — não como ordem cega.
        </p>
      </div>

      {items.length > 0 ? (
        <button
          type="button"
          onClick={clear}
          className={cn(
            "h-11 w-full rounded-xl bg-elevated text-sm text-muted",
            "transition-transform duration-150 ease-out active:scale-[0.96]",
          )}
        >
          Limpar histórico local
        </button>
      ) : null}
    </div>
  );
}
