import { useEffect, useState } from "react";
import { ShieldAlert } from "lucide-react";
import { LogoMark } from "@/components/logo";
import { useGateStore } from "@/lib/store";

export function DisclaimerGate() {
  const accepted = useGateStore((s) => s.accepted);
  const accept = useGateStore((s) => s.accept);
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  if (!ready || accepted) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-bg/80 p-4 sm:items-center">
      <div className="w-full max-w-md rounded-2xl bg-surface p-5 shadow-[var(--shadow-lift)] sm:p-6">
        <div className="flex items-center gap-3">
          <span className="flex size-10 items-center justify-center rounded-lg bg-elevated text-accent">
            <LogoMark className="size-5" />
          </span>
          <div>
            <p className="font-display text-lg font-semibold tracking-tight">NEXA</p>
            <p className="text-sm text-muted">Sinais EUR/USD, forex e cripto em dólar</p>
          </div>
        </div>
        <div className="mt-5 flex gap-3 rounded-xl bg-elevated p-4">
          <ShieldAlert className="mt-0.5 size-5 shrink-0 text-accent" />
          <div className="space-y-2 text-sm leading-relaxed text-muted">
            <p>
              Opções binárias digitais são de alto risco e podem resultar na perda
              total do capital.
            </p>
            <p>
              A NEXA gera sinais de EUR/USD e outros pares cotados em dólar (não
              stablecoin) por confluência de indicadores (EMA, RSI, MACD,
              estocástico, Bollinger, ADX) sobre cotações reais. Isso não é
              garantia de lucro nem recomendação de investimento.
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={accept}
          className="mt-5 flex h-12 w-full items-center justify-center rounded-xl bg-fg text-sm font-medium text-bg transition-transform duration-150 ease-out active:scale-[0.96]"
        >
          Entendi, continuar
        </button>
      </div>
    </div>
  );
}
