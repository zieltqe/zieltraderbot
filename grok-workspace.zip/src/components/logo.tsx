export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path
        d="M4 16.5 9.4 8.2c.3-.45.94-.5 1.32-.1L14.2 12l5.3-8"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.9"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="19.6" cy="4.2" r="1.15" fill="currentColor" />
    </svg>
  );
}
