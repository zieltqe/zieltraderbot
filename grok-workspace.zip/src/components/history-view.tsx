import { ASSET_MAP } from "@/lib/market/assets";
import { useHistoryStore, type HistoryItem } from "@/lib/history";
import { cn, formatPrice, formatTime } from "@/lib/utils";

function ResultBadge({ item }: { item: HistoryItem }) {
  const map = {
    win: { label: "Win", className: "bg-call-dim text-call" },
    loss: { label: "Loss", className: "bg-put-dim text-put" },
    void: { label: "Empate", className: "bg-elevated text-muted" },
    pending: { label: "Aberto", className: "bg-elevated text-accent" },
  } as const;
  const v = map[item.result];
  return (
    <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide", v.className)}>
      {v.label}
    </span>
  );
}

export function HistoryView() {
  const items = useHistoryStore((s) => s.items);

  return (
    <div className="pb-4">
      <header className="px-1 pb-3">
        <h2 className="font-display text-2xl font-semibold">Histórico</h2>
        <p className="mt-1 text-sm text-muted">
          Cada sinal é liquidado no fechamento do candle, contra o preço real.
        </p>
      </header>
      {items.length === 0 ? (
        <div className="rounded-xl bg-surface px-4 py-10 text-center shadow-[var(--shadow-border)]">
          <p className="font-medium">Nenhum sinal ainda</p>
          <p className="mt-1 text-sm text-muted">
            Quando um setup de confluência aparecer, ele entra aqui automaticamente.
          </p>
        </div>
      ) : (
        <ul className="space-y-2">
          {items.map((item) => {
            const asset = ASSET_MAP[item.assetId];
            if (!asset) return null;
            const call = item.direction === "call";
            return (
              <li
                key={item.id}
                className="flex items-center gap-3 rounded-xl bg-surface px-3 py-3 shadow-[var(--shadow-border)]"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-medium">{asset.pair}</p>
                    <span className="text-[10px] uppercase tracking-wide text-subtle">
                      {item.interval}
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs text-muted">
                    <span className={call ? "text-call" : "text-put"}>{call ? "ALTA" : "BAIXA"}</span>
                    {" · "}
                    {formatTime(item.issuedAt)}
                    {" · força "}
                    <span className="font-mono tabular-nums">{item.confidence}</span>
                  </p>
                  <p className="mt-1 font-mono text-[11px] tabular-nums text-subtle">
                    {formatPrice(item.entryPrice, asset.decimals)}
                    {item.exitPrice != null ? ` → ${formatPrice(item.exitPrice, asset.decimals)}` : ""}
                  </p>
                </div>
                <ResultBadge item={item} />
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
