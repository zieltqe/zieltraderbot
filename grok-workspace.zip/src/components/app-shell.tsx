import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { RefreshCw } from "lucide-react";
import { getSignalFeed } from "@/lib/market/api";
import { ASSET_MAP, matchesMarket } from "@/lib/market/assets";
import type { AssetSnapshot, FeedResponse } from "@/lib/market/types";
import { useHistoryStore } from "@/lib/history";
import { useUiStore, type MarketFilter } from "@/lib/store";
import { cn, formatTime } from "@/lib/utils";
import { AssetsView } from "@/components/assets-view";
import { BottomNav } from "@/components/bottom-nav";
import { DisclaimerGate } from "@/components/disclaimer-gate";
import { FeedList } from "@/components/feed-list";
import { HistoryView } from "@/components/history-view";
import { LogoMark } from "@/components/logo";
import { SignalHero } from "@/components/signal-hero";
import { StatsView } from "@/components/stats-view";

function HeaderClock() {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    setNow(Date.now());
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);
  return (
    <div className="text-right">
      <p className="font-mono text-sm tabular-nums text-fg">
        {now ? formatTime(now) : "--:--:--"}
      </p>
      <p className="flex items-center justify-end gap-1.5 text-[10px] uppercase tracking-[0.14em] text-subtle">
        <span className="live-dot size-1.5 rounded-full bg-call" />
        Ao vivo
      </p>
    </div>
  );
}

const MARKETS: { id: MarketFilter; label: string }[] = [
  { id: "forex", label: "Forex" },
  { id: "crypto", label: "Cripto" },
  { id: "all", label: "Todos" },
];

function MarketSwitch() {
  const market = useUiStore((s) => s.market);
  const setMarket = useUiStore((s) => s.setMarket);
  return (
    <div className="grid grid-cols-3 gap-1 rounded-xl bg-elevated p-1">
      {MARKETS.map((item) => {
        const active = market === item.id;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => setMarket(item.id)}
            className={cn(
              "h-10 rounded-lg text-sm font-medium transition-colors duration-150",
              active ? "bg-panel text-fg shadow-[var(--shadow-border)]" : "text-subtle",
            )}
          >
            {item.label}
          </button>
        );
      })}
    </div>
  );
}

function IntervalSwitch() {
  const interval = useUiStore((s) => s.interval);
  const setInterval = useUiStore((s) => s.setInterval);
  return (
    <div className="relative grid grid-cols-2 rounded-xl bg-elevated p-1">
      <span
        className="absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-lg bg-panel shadow-[var(--shadow-border)] transition-transform duration-200 ease-out"
        style={{ transform: interval === "5m" ? "translateX(calc(100% + 4px))" : "translateX(4px)" }}
      />
      {(["1m", "5m"] as const).map((id) => (
        <button
          key={id}
          type="button"
          onClick={() => setInterval(id)}
          className={cn(
            "relative z-10 h-10 text-sm font-medium transition-colors duration-150",
            interval === id ? "text-fg" : "text-subtle",
          )}
        >
          {id === "1m" ? "1 minuto" : "5 minutos"}
        </button>
      ))}
    </div>
  );
}

function filterSnapshots(snapshots: AssetSnapshot[], market: MarketFilter) {
  return snapshots.filter((s) => {
    const asset = ASSET_MAP[s.quote.assetId];
    return asset ? matchesMarket(asset, market) : false;
  });
}

function SignalsBody({ initialFeed }: { initialFeed?: FeedResponse }) {
  const interval = useUiStore((s) => s.interval);
  const market = useUiStore((s) => s.market);
  const selectedId = useUiStore((s) => s.selectedId);
  const ingest = useHistoryStore((s) => s.ingest);
  const settle = useHistoryStore((s) => s.settle);

  const query = useQuery({
    queryKey: ["feed", interval],
    queryFn: () => getSignalFeed({ data: { interval } }),
    refetchInterval: 8000,
    initialData: interval === "1m" ? initialFeed : undefined,
  });

  const refetch = query.refetch;

  useEffect(() => {
    if (!query.data) return;
    const signals = query.data.snapshots.flatMap((s) => (s.signal ? [s.signal] : []));
    ingest(signals);
    settle(
      query.data.snapshots.map((s) => s.quote),
      Date.now(),
    );
  }, [query.data, ingest, settle]);

  const snapshots = useMemo(
    () => (query.data ? filterSnapshots(query.data.snapshots, market) : []),
    [query.data, market],
  );

  const selected =
    snapshots.find((s) => s.quote.assetId === selectedId) ??
    snapshots.find((s) => s.quote.assetId === "eurusd") ??
    snapshots.find((s) => s.signal?.tradeable) ??
    snapshots[0];

  const expiryAt = selected?.signal?.expiryAt;
  useEffect(() => {
    if (!expiryAt) return;
    const wait = Math.max(800, expiryAt - Date.now() + 700);
    const id = window.setTimeout(() => {
      void refetch();
    }, wait);
    return () => window.clearTimeout(id);
  }, [expiryAt, refetch]);

  if (query.isLoading && !query.data) {
    return (
      <div className="space-y-3">
        <p className="px-1 text-sm text-muted">Carregando EUR/USD e os pares em dólar…</p>
        <div className="h-12 rounded-xl bg-elevated" />
        <div className="h-12 rounded-xl bg-elevated" />
        <div className="h-80 rounded-2xl bg-surface" />
        <div className="h-16 rounded-xl bg-surface" />
        <div className="h-16 rounded-xl bg-surface" />
      </div>
    );
  }

  if (query.isError || !query.data || snapshots.length === 0) {
    return (
      <div className="rounded-2xl bg-surface px-4 py-10 text-center shadow-[var(--shadow-border)]">
        <p className="font-display text-lg font-medium">Sem cotações agora</p>
        <p className="mt-2 text-sm text-muted">
          Não foi possível ler EUR/USD e os outros pares em dólar. Tente de novo em alguns
          segundos.
        </p>
        <button
          type="button"
          onClick={() => query.refetch()}
          className="mt-5 inline-flex h-11 items-center gap-2 rounded-xl bg-fg px-4 text-sm font-medium text-bg transition-transform duration-150 active:scale-[0.96]"
        >
          <RefreshCw className="size-4" />
          Tentar novamente
        </button>
      </div>
    );
  }

  if (!selected) return null;

  return (
    <div>
      <MarketSwitch />
      <div className="mt-2">
        <IntervalSwitch />
      </div>
      <div className="mt-4">
        <SignalHero snapshot={selected} interval={interval} />
      </div>
      <FeedList snapshots={snapshots} selectedId={selected.quote.assetId} />
    </div>
  );
}

function AssetsPane({ initialFeed }: { initialFeed?: FeedResponse }) {
  const interval = useUiStore((s) => s.interval);
  const market = useUiStore((s) => s.market);
  const query = useQuery({
    queryKey: ["feed", interval],
    queryFn: () => getSignalFeed({ data: { interval } }),
    refetchInterval: 8000,
    initialData: interval === "1m" ? initialFeed : undefined,
  });
  if (!query.data) {
    return (
      <div className="space-y-2">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="h-16 rounded-xl bg-surface" />
        ))}
      </div>
    );
  }
  return (
    <div>
      <MarketSwitch />
      <div className="mt-4">
        <AssetsView snapshots={filterSnapshots(query.data.snapshots, market)} />
      </div>
    </div>
  );
}

export function AppShell({ initialFeed }: { initialFeed?: FeedResponse }) {
  const tab = useUiStore((s) => s.tab);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-20 flex items-center justify-between bg-bg/90 px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-3 backdrop-blur-sm">
        <div className="flex items-center gap-2.5">
          <span className="flex size-9 items-center justify-center rounded-lg bg-elevated text-accent">
            <LogoMark className="size-5" />
          </span>
          <div>
            <p className="font-display text-lg font-semibold leading-none tracking-tight">NEXA</p>
            <p className="mt-1 text-[11px] uppercase tracking-[0.16em] text-subtle">
              EUR/USD ao vivo
            </p>
          </div>
        </div>
        <HeaderClock />
      </header>

      <main className="mx-auto w-full max-w-lg px-4 pb-28">
        {tab === "sinais" ? <SignalsBody initialFeed={initialFeed} /> : null}
        {tab === "ativos" ? <AssetsPane initialFeed={initialFeed} /> : null}
        {tab === "historico" ? <HistoryView /> : null}
        {tab === "desempenho" ? <StatsView /> : null}
      </main>

      <BottomNav />
      <DisclaimerGate />
    </div>
  );
}
