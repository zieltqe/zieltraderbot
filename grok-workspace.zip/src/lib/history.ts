import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Direction, Interval, LiveSignal, Quality, Quote } from "@/lib/market/types";

export type SignalResult = "pending" | "win" | "loss" | "void";

export type HistoryItem = {
  id: string;
  assetId: string;
  interval: Interval;
  direction: Direction;
  confidence: number;
  quality: Quality;
  entryPrice: number;
  exitPrice?: number;
  issuedAt: number;
  expiryAt: number;
  result: SignalResult;
};

type HistoryState = {
  items: HistoryItem[];
  ingest: (signals: LiveSignal[]) => void;
  settle: (quotes: Quote[], now: number) => void;
  clear: () => void;
};

const MAX = 120;

export const useHistoryStore = create<HistoryState>()(
  persist(
    (set, get) => ({
      items: [],
      ingest: (signals) => {
        const tradeable = signals.filter((s) => s.tradeable);
        if (!tradeable.length) return;
        const existing = get().items;
        const next = [...existing];
        for (const s of tradeable) {
          const id = `${s.assetId}:${s.interval}:${s.expiryAt}`;
          if (next.some((i) => i.id === id)) continue;
          next.unshift({
            id,
            assetId: s.assetId,
            interval: s.interval,
            direction: s.direction,
            confidence: s.confidence,
            quality: s.quality,
            entryPrice: s.entryPrice,
            issuedAt: s.issuedAt,
            expiryAt: s.expiryAt,
            result: "pending",
          });
        }
        set({ items: next.slice(0, MAX) });
      },
      settle: (quotes, now) => {
        const byId = new Map(quotes.map((q) => [q.assetId, q]));
        let changed = false;
        const items = get().items.map((item) => {
          if (item.result !== "pending") return item;
          if (item.expiryAt > now + 400) return item;
          const quote = byId.get(item.assetId);
          if (!quote) return item;
          const exit = quote.price;
          const delta = exit - item.entryPrice;
          const eps = Math.max(item.entryPrice * 1e-6, 1e-8);
          let result: SignalResult = "void";
          if (Math.abs(delta) > eps) {
            const won =
              (item.direction === "call" && delta > 0) ||
              (item.direction === "put" && delta < 0);
            result = won ? "win" : "loss";
          }
          changed = true;
          return { ...item, exitPrice: exit, result };
        });
        if (changed) set({ items });
      },
      clear: () => set({ items: [] }),
    }),
    { name: "nexa-history" },
  ),
);

export function summarize(items: HistoryItem[]) {
  const settled = items.filter((i) => i.result === "win" || i.result === "loss");
  const wins = settled.filter((i) => i.result === "win").length;
  const losses = settled.filter((i) => i.result === "loss").length;
  const pending = items.filter((i) => i.result === "pending").length;
  const hitRate = settled.length ? wins / settled.length : 0;
  let streak = 0;
  for (const item of items) {
    if (item.result === "pending" || item.result === "void") continue;
    if (streak === 0) {
      streak = item.result === "win" ? 1 : -1;
      continue;
    }
    if (streak > 0 && item.result === "win") streak++;
    else if (streak < 0 && item.result === "loss") streak--;
    else break;
  }
  const byAsset = new Map<string, { wins: number; n: number }>();
  for (const item of settled) {
    const cur = byAsset.get(item.assetId) ?? { wins: 0, n: 0 };
    cur.n += 1;
    if (item.result === "win") cur.wins += 1;
    byAsset.set(item.assetId, cur);
  }
  let best: { assetId: string; hitRate: number; n: number } | null = null;
  for (const [assetId, v] of byAsset) {
    if (v.n < 3) continue;
    const rate = v.wins / v.n;
    if (!best || rate > best.hitRate) best = { assetId, hitRate: rate, n: v.n };
  }
  return { wins, losses, pending, settled: settled.length, hitRate, streak, best };
}
