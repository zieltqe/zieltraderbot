import { create } from "zustand";
import { persist } from "zustand/middleware";
import { ASSET_MAP } from "@/lib/market/assets";
import type { Interval } from "@/lib/market/types";

export type TabId = "sinais" | "ativos" | "historico" | "desempenho";
export type MarketFilter = "forex" | "crypto" | "all";

type UiState = {
  tab: TabId;
  interval: Interval;
  market: MarketFilter;
  selectedId: string;
  setTab: (tab: TabId) => void;
  setInterval: (interval: Interval) => void;
  setMarket: (market: MarketFilter) => void;
  setSelectedId: (id: string) => void;
};

export const useUiStore = create<UiState>()((set) => ({
  tab: "sinais",
  interval: "1m",
  market: "forex",
  selectedId: "eurusd",
  setTab: (tab) => set({ tab }),
  setInterval: (interval) => set({ interval }),
  setMarket: (market) =>
    set((s) => {
      const asset = ASSET_MAP[s.selectedId];
      let selectedId = s.selectedId;
      if (market === "forex" && asset?.class === "crypto") selectedId = "eurusd";
      if (market === "crypto" && asset?.class !== "crypto") selectedId = "btcusd";
      return { market, selectedId };
    }),
  setSelectedId: (selectedId) => set({ selectedId, tab: "sinais" }),
}));

type GateState = {
  accepted: boolean;
  accept: () => void;
};

export const useGateStore = create<GateState>()(
  persist(
    (set) => ({
      accepted: false,
      accept: () => set({ accepted: true }),
    }),
    { name: "nexa-gate" },
  ),
);
