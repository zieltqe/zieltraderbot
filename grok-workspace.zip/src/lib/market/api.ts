import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { FeedResponse, Interval } from "./types";

const intervalSchema = z.enum(["1m", "5m"]);

export const getSignalFeed = createServerFn({ method: "POST" })
  .validator((input: { interval: Interval }) => ({
    interval: intervalSchema.parse(input.interval),
  }))
  .handler(async ({ data }): Promise<FeedResponse> => {
    const { buildFeed } = await import("./feed.server.ts");
    return buildFeed(data.interval);
  });
