import type { AssetClass } from "./types";

export type FallbackSource =
  | { kind: "twelve"; symbol: string }
  | { kind: "okx-index"; instId: string }
  | { kind: "coinbase"; product: string }
  | { kind: "okx"; instId: string }
  | { kind: "yahoo"; ticker: string };

export type Asset = {
  id: string;
  pair: string;
  name: string;
  class: AssetClass;
  decimals: number;
  biquote: string;
  fallbacks?: FallbackSource[];
};

export const ASSETS: Asset[] = [
  {
    id: "eurusd",
    pair: "EUR/USD",
    name: "Euro / Dólar",
    class: "forex",
    decimals: 5,
    biquote: "EURUSD",
    fallbacks: [
      { kind: "twelve", symbol: "EUR/USD" },
      { kind: "okx-index", instId: "EUR-USD" },
      { kind: "yahoo", ticker: "EURUSD=X" },
    ],
  },
  {
    id: "gbpusd",
    pair: "GBP/USD",
    name: "Libra / Dólar",
    class: "forex",
    decimals: 5,
    biquote: "GBPUSD",
    fallbacks: [{ kind: "yahoo", ticker: "GBPUSD=X" }],
  },
  {
    id: "usdjpy",
    pair: "USD/JPY",
    name: "Dólar / Iene",
    class: "forex",
    decimals: 3,
    biquote: "USDJPY",
    fallbacks: [
      { kind: "okx-index", instId: "USD-JPY" },
      { kind: "yahoo", ticker: "JPY=X" },
    ],
  },
  {
    id: "audusd",
    pair: "AUD/USD",
    name: "Aussie / Dólar",
    class: "forex",
    decimals: 5,
    biquote: "AUDUSD",
    fallbacks: [
      { kind: "okx-index", instId: "AUD-USD" },
      { kind: "yahoo", ticker: "AUDUSD=X" },
    ],
  },
  {
    id: "eurjpy",
    pair: "EUR/JPY",
    name: "Euro / Iene",
    class: "forex",
    decimals: 3,
    biquote: "EURJPY",
    fallbacks: [{ kind: "yahoo", ticker: "EURJPY=X" }],
  },
  {
    id: "eurgbp",
    pair: "EUR/GBP",
    name: "Euro / Libra",
    class: "forex",
    decimals: 5,
    biquote: "EURGBP",
    fallbacks: [{ kind: "yahoo", ticker: "EURGBP=X" }],
  },
  {
    id: "xauusd",
    pair: "XAU/USD",
    name: "Ouro",
    class: "commodity",
    decimals: 2,
    biquote: "XAUUSD",
    fallbacks: [
      { kind: "okx-index", instId: "XAU-USD" },
      { kind: "yahoo", ticker: "GC=F" },
    ],
  },
  {
    id: "btcusd",
    pair: "BTC/USD",
    name: "Bitcoin",
    class: "crypto",
    decimals: 2,
    biquote: "BTCUSD",
    fallbacks: [
      { kind: "coinbase", product: "BTC-USD" },
      { kind: "okx", instId: "BTC-USDT" },
      { kind: "yahoo", ticker: "BTC-USD" },
    ],
  },
  {
    id: "ethusd",
    pair: "ETH/USD",
    name: "Ethereum",
    class: "crypto",
    decimals: 2,
    biquote: "ETHUSD",
    fallbacks: [
      { kind: "coinbase", product: "ETH-USD" },
      { kind: "okx", instId: "ETH-USDT" },
      { kind: "yahoo", ticker: "ETH-USD" },
    ],
  },
  {
    id: "solusd",
    pair: "SOL/USD",
    name: "Solana",
    class: "crypto",
    decimals: 3,
    biquote: "SOLUSD",
    fallbacks: [
      { kind: "coinbase", product: "SOL-USD" },
      { kind: "okx", instId: "SOL-USDT" },
      { kind: "yahoo", ticker: "SOL-USD" },
    ],
  },
];

export const ASSET_MAP = Object.fromEntries(ASSETS.map((a) => [a.id, a])) as Record<
  string,
  Asset
>;

export function getAsset(id: string): Asset {
  const asset = ASSET_MAP[id];
  if (!asset) throw new Error(`Ativo desconhecido: ${id}`);
  return asset;
}

export function matchesMarket(asset: Asset, market: "forex" | "crypto" | "all") {
  if (market === "all") return true;
  if (market === "crypto") return asset.class === "crypto";
  return asset.class !== "crypto";
}

export const INTERVAL_MS = { "1m": 60_000, "5m": 300_000 } as const;
