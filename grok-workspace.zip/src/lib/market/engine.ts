import { INTERVAL_MS } from "./assets";
import {
  adx as calcAdx,
  atr as calcAtr,
  ema,
  lastNumber,
  macd,
  prevNumber,
  rsi as calcRsi,
  sma,
  stdev,
  stochastic,
} from "./indicators";
import type {
  Analysis,
  AssetClass,
  Backtest,
  Candle,
  Direction,
  Interval,
  LiveSignal,
  Quality,
  Vote,
} from "./types";

const MIN_CANDLES = 55;

function classParams(assetClass: AssetClass) {
  if (assetClass === "forex") {
    return { minAtrPct: 0.0012, quietAtrPct: 0.0028, mom: 0.00012 };
  }
  if (assetClass === "commodity") {
    return { minAtrPct: 0.0035, quietAtrPct: 0.007, mom: 0.00035 };
  }
  return { minAtrPct: 0.008, quietAtrPct: 0.012, mom: 0.0008 };
}

function qualityOf(confidence: number, agreeing: number, votes: number): Quality {
  if (confidence >= 86 && agreeing >= 5) return "elite";
  if (confidence >= 74 && agreeing >= 4) return "strong";
  if (confidence >= 62 && agreeing >= 3) return "medium";
  void votes;
  return "weak";
}

function body(c: Candle) {
  return Math.abs(c.close - c.open);
}

function range(c: Candle) {
  return Math.max(c.high - c.low, 1e-12);
}

function isBullEngulf(prev: Candle, cur: Candle) {
  return (
    prev.close < prev.open &&
    cur.close > cur.open &&
    cur.close >= prev.open &&
    cur.open <= prev.close &&
    body(cur) > body(prev) * 1.05
  );
}

function isBearEngulf(prev: Candle, cur: Candle) {
  return (
    prev.close > prev.open &&
    cur.close < cur.open &&
    cur.open >= prev.close &&
    cur.close <= prev.open &&
    body(cur) > body(prev) * 1.05
  );
}

function isPin(c: Candle, side: "low" | "high") {
  const b = body(c);
  const wickLow = Math.min(c.open, c.close) - c.low;
  const wickHigh = c.high - Math.max(c.open, c.close);
  if (side === "low") return wickLow > b * 2 && wickHigh < b * 0.8 && b / range(c) < 0.4;
  return wickHigh > b * 2 && wickLow < b * 0.8 && b / range(c) < 0.4;
}

export function analyze(candles: Candle[], assetClass: AssetClass = "crypto"): Analysis | null {
  const closed = candles.filter((c) => c.closed);
  if (closed.length < MIN_CANDLES) return null;
  const params = classParams(assetClass);

  const close = closed.map((c) => c.close);
  const high = closed.map((c) => c.high);
  const low = closed.map((c) => c.low);
  const n = closed.length;
  const cur = closed[n - 1]!;
  const prev = closed[n - 2]!;
  const prev2 = closed[n - 3]!;

  const ema8 = ema(close, 8);
  const ema21 = ema(close, 21);
  const ema50 = ema(close, 50);
  const rsi = calcRsi(close, 14);
  const macdSet = macd(close);
  const stoch = stochastic(high, low, close);
  const mid = sma(close, 20);
  const sd = stdev(close, 20);
  const atr = calcAtr(high, low, close, 14);
  const adxArr = calcAdx(high, low, close, 14);

  const e8 = lastNumber(ema8);
  const e21 = lastNumber(ema21);
  const e50 = lastNumber(ema50);
  const e8p = prevNumber(ema8);
  const e21p = prevNumber(ema21);
  const r = lastNumber(rsi);
  const rp = prevNumber(rsi);
  const macdH = lastNumber(macdSet.hist);
  const macdHp = prevNumber(macdSet.hist);
  const macdL = lastNumber(macdSet.line);
  const macdS = lastNumber(macdSet.signal);
  const k = lastNumber(stoch.k);
  const d = lastNumber(stoch.d);
  const kp = prevNumber(stoch.k);
  const dp = prevNumber(stoch.d);
  const bbMid = lastNumber(mid);
  const bbSd = lastNumber(sd);
  const atrV = lastNumber(atr);
  const adxV = lastNumber(adxArr) ?? 0;

  if (e8 == null || e21 == null || e50 == null || r == null || atrV == null || bbMid == null || bbSd == null) {
    return null;
  }

  const atrPct = (atrV / cur.close) * 100;
  const regime = adxV >= 22 ? "trend" : "range";
  const votes: Vote[] = [];

  const stackedUp = e8 > e21 && e21 > e50;
  const stackedDown = e8 < e21 && e21 < e50;
  if (stackedUp) {
    votes.push({
      id: "ema-stack",
      label: "Tendência EMA",
      direction: "call",
      weight: 1.4,
      detail: "EMA 8 > 21 > 50 — tendência de alta alinhada",
    });
  } else if (stackedDown) {
    votes.push({
      id: "ema-stack",
      label: "Tendência EMA",
      direction: "put",
      weight: 1.4,
      detail: "EMA 8 < 21 < 50 — tendência de baixa alinhada",
    });
  } else if (e8 > e21) {
    votes.push({
      id: "ema-stack",
      label: "Tendência EMA",
      direction: "call",
      weight: 0.6,
      detail: "EMA rápida acima da lenta",
    });
  } else {
    votes.push({
      id: "ema-stack",
      label: "Tendência EMA",
      direction: "put",
      weight: 0.6,
      detail: "EMA rápida abaixo da lenta",
    });
  }

  if (e8p != null && e21p != null) {
    if (e8p <= e21p && e8 > e21) {
      votes.push({
        id: "ema-cross",
        label: "Cruzamento EMA",
        direction: "call",
        weight: 1.3,
        detail: "Cruzamento de alta da EMA 8 × 21",
      });
    } else if (e8p >= e21p && e8 < e21) {
      votes.push({
        id: "ema-cross",
        label: "Cruzamento EMA",
        direction: "put",
        weight: 1.3,
        detail: "Cruzamento de baixa da EMA 8 × 21",
      });
    }
  }

  if (regime === "range") {
    if (r <= 32 && (rp == null || r > rp)) {
      votes.push({
        id: "rsi",
        label: "RSI",
        direction: "call",
        weight: 1.35,
        detail: `RSI ${r.toFixed(1)} em sobrevenda com reversão`,
      });
    } else if (r >= 68 && (rp == null || r < rp)) {
      votes.push({
        id: "rsi",
        label: "RSI",
        direction: "put",
        weight: 1.35,
        detail: `RSI ${r.toFixed(1)} em sobrecompra com reversão`,
      });
    } else {
      votes.push({
        id: "rsi",
        label: "RSI",
        direction: "neutral",
        weight: 0.2,
        detail: `RSI ${r.toFixed(1)} neutro no range`,
      });
    }
  } else if (r >= 54) {
    votes.push({
      id: "rsi",
      label: "RSI",
      direction: "call",
      weight: r >= 62 ? 1.1 : 0.7,
      detail: `RSI ${r.toFixed(1)} confirma momentum de alta`,
    });
  } else if (r <= 46) {
    votes.push({
      id: "rsi",
      label: "RSI",
      direction: "put",
      weight: r <= 38 ? 1.1 : 0.7,
      detail: `RSI ${r.toFixed(1)} confirma momentum de baixa`,
    });
  }

  if (macdH != null && macdHp != null) {
    if (macdL != null && macdS != null && macdL > macdS && macdHp <= 0 && macdH > 0) {
      votes.push({
        id: "macd",
        label: "MACD",
        direction: "call",
        weight: 1.4,
        detail: "MACD cruzou acima da sinal com histograma positivo",
      });
    } else if (macdL != null && macdS != null && macdL < macdS && macdHp >= 0 && macdH < 0) {
      votes.push({
        id: "macd",
        label: "MACD",
        direction: "put",
        weight: 1.4,
        detail: "MACD cruzou abaixo da sinal com histograma negativo",
      });
    } else if (macdH > 0 && macdH > macdHp) {
      votes.push({
        id: "macd",
        label: "MACD",
        direction: "call",
        weight: 1.0,
        detail: "Histograma MACD acelerando para cima",
      });
    } else if (macdH < 0 && macdH < macdHp) {
      votes.push({
        id: "macd",
        label: "MACD",
        direction: "put",
        weight: 1.0,
        detail: "Histograma MACD acelerando para baixo",
      });
    }
  }

  if (k != null && d != null) {
    if (kp != null && dp != null && kp < dp && k > d && k < 30) {
      votes.push({
        id: "stoch",
        label: "Estocástico",
        direction: "call",
        weight: 1.25,
        detail: `Estocástico cruzou no suporte (${k.toFixed(0)})`,
      });
    } else if (kp != null && dp != null && kp > dp && k < d && k > 70) {
      votes.push({
        id: "stoch",
        label: "Estocástico",
        direction: "put",
        weight: 1.25,
        detail: `Estocástico cruzou na resistência (${k.toFixed(0)})`,
      });
    } else if (k < 22) {
      votes.push({
        id: "stoch",
        label: "Estocástico",
        direction: "call",
        weight: 0.7,
        detail: "Estocástico em sobrevenda",
      });
    } else if (k > 78) {
      votes.push({
        id: "stoch",
        label: "Estocástico",
        direction: "put",
        weight: 0.7,
        detail: "Estocástico em sobrecompra",
      });
    }
  }

  const upper = bbMid + 2 * bbSd;
  const lower = bbMid - 2 * bbSd;
  if (cur.close <= lower && r < 40) {
    votes.push({
      id: "bb",
      label: "Bollinger",
      direction: "call",
      weight: 1.3,
      detail: "Preço na banda inferior com RSI baixo",
    });
  } else if (cur.close >= upper && r > 60) {
    votes.push({
      id: "bb",
      label: "Bollinger",
      direction: "put",
      weight: 1.3,
      detail: "Preço na banda superior com RSI alto",
    });
  } else if (regime === "trend" && cur.close > bbMid && stackedUp) {
    votes.push({
      id: "bb",
      label: "Bollinger",
      direction: "call",
      weight: 0.6,
      detail: "Preço acima da média das bandas, tendência de alta",
    });
  } else if (regime === "trend" && cur.close < bbMid && stackedDown) {
    votes.push({
      id: "bb",
      label: "Bollinger",
      direction: "put",
      weight: 0.6,
      detail: "Preço abaixo da média das bandas, tendência de baixa",
    });
  }

  if (isBullEngulf(prev, cur) || isPin(cur, "low")) {
    votes.push({
      id: "candle",
      label: "Candle",
      direction: "call",
      weight: 1.2,
      detail: isBullEngulf(prev, cur) ? "Engolfo de alta" : "Pavio inferior (pin bar de alta)",
    });
  } else if (isBearEngulf(prev, cur) || isPin(cur, "high")) {
    votes.push({
      id: "candle",
      label: "Candle",
      direction: "put",
      weight: 1.2,
      detail: isBearEngulf(prev, cur) ? "Engolfo de baixa" : "Pavio superior (pin bar de baixa)",
    });
  } else if (cur.close > cur.open && prev.close > prev.open && prev2.close > prev2.open) {
    votes.push({
      id: "candle",
      label: "Candle",
      direction: "call",
      weight: 0.8,
      detail: "Três candles consecutivos de alta",
    });
  } else if (cur.close < cur.open && prev.close < prev.open && prev2.close < prev2.open) {
    votes.push({
      id: "candle",
      label: "Candle",
      direction: "put",
      weight: 0.8,
      detail: "Três candles consecutivos de baixa",
    });
  }

  const mom = (cur.close - closed[n - 4]!.close) / closed[n - 4]!.close;
  if (mom > params.mom) {
    votes.push({
      id: "mom",
      label: "Momentum",
      direction: "call",
      weight: 0.7,
      detail: "Impulso de alta nas últimas velas",
    });
  } else if (mom < -params.mom) {
    votes.push({
      id: "mom",
      label: "Momentum",
      direction: "put",
      weight: 0.7,
      detail: "Impulso de baixa nas últimas velas",
    });
  }

  if (adxV >= 25 && stackedUp) {
    votes.push({
      id: "adx",
      label: "ADX",
      direction: "call",
      weight: 0.9,
      detail: `ADX ${adxV.toFixed(1)} — tendência de alta forte`,
    });
  } else if (adxV >= 25 && stackedDown) {
    votes.push({
      id: "adx",
      label: "ADX",
      direction: "put",
      weight: 0.9,
      detail: `ADX ${adxV.toFixed(1)} — tendência de baixa forte`,
    });
  }

  const directed = votes.filter((v) => v.direction !== "neutral");
  const callScore = directed.filter((v) => v.direction === "call").reduce((s, v) => s + v.weight, 0);
  const putScore = directed.filter((v) => v.direction === "put").reduce((s, v) => s + v.weight, 0);
  const total = callScore + putScore;
  if (total <= 0) return null;

  const direction: Direction = callScore >= putScore ? "call" : "put";
  const win = direction === "call" ? callScore : putScore;
  const lose = direction === "call" ? putScore : callScore;
  const dominance = (win - lose) / total;
  const agreeing = directed.filter((v) => v.direction === direction).length;
  const coverage = agreeing / Math.max(directed.length, 1);

  let confidence = Math.round(52 + dominance * 38 + coverage * 10);
  if (atrPct < params.quietAtrPct) confidence -= 8;
  if (regime === "trend" && adxV >= 28) confidence += 3;
  confidence = Math.max(50, Math.min(94, confidence));

  if (atrPct < params.minAtrPct) confidence = Math.min(confidence, 60);

  const quality = qualityOf(confidence, agreeing, directed.length);
  const tradeable = quality !== "weak" && dominance >= 0.18 && atrPct >= params.minAtrPct;

  const reasons = directed
    .filter((v) => v.direction === direction)
    .sort((a, b) => b.weight - a.weight)
    .slice(0, 4)
    .map((v) => v.detail);

  return {
    direction,
    confidence,
    quality,
    tradeable,
    votes,
    agreeing,
    reasons,
    regime,
    adx: adxV,
    rsi: r,
    atrPct,
    emaFast: e8,
    emaSlow: e21,
  };
}

export function backtest(candles: Candle[], assetClass: AssetClass = "crypto"): Backtest {
  const closed = candles.filter((c) => c.closed);
  let wins = 0;
  let losses = 0;
  const start = Math.max(MIN_CANDLES, closed.length - 40);
  for (let i = start; i < closed.length - 1; i++) {
    const window = closed.slice(0, i + 1).map((c) => ({ ...c, closed: true }));
    const sig = analyze(window, assetClass);
    if (!sig?.tradeable) continue;
    const entry = closed[i]!.close;
    const exit = closed[i + 1]!.close;
    if (exit === entry) continue;
    const won =
      (sig.direction === "call" && exit > entry) || (sig.direction === "put" && exit < entry);
    if (won) wins++;
    else losses++;
  }
  const sample = wins + losses;
  return { sample, wins, losses, hitRate: sample ? wins / sample : 0 };
}

export function toLiveSignal(
  assetId: string,
  interval: Interval,
  candles: Candle[],
  analysis: Analysis,
  now: number,
): LiveSignal {
  const closed = candles.filter((c) => c.closed);
  const last = closed[closed.length - 1]!;
  const ms = INTERVAL_MS[interval];
  const issuedAt = last.time + ms;
  const expiryAt = issuedAt + ms;
  return {
    assetId,
    interval,
    direction: analysis.direction,
    confidence: analysis.confidence,
    quality: analysis.quality,
    tradeable: analysis.tradeable,
    reasons: analysis.reasons,
    votes: analysis.votes,
    regime: analysis.regime,
    rsi: analysis.rsi,
    adx: analysis.adx,
    atrPct: analysis.atrPct,
    entryPrice: last.close,
    issuedAt,
    expiryAt,
    serverNow: now,
  };
}
