export type Interval = "1m" | "5m";
export type Direction = "call" | "put";
export type Quality = "weak" | "medium" | "strong" | "elite";
export type Regime = "trend" | "range";
export type AssetClass = "forex" | "crypto" | "commodity";

export type Candle = {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  closed: boolean;
};

export type Vote = {
  id: string;
  label: string;
  direction: Direction | "neutral";
  weight: number;
  detail: string;
};

export type Analysis = {
  direction: Direction;
  confidence: number;
  quality: Quality;
  tradeable: boolean;
  votes: Vote[];
  agreeing: number;
  reasons: string[];
  regime: Regime;
  adx: number;
  rsi: number;
  atrPct: number;
  emaFast: number;
  emaSlow: number;
};

export type Backtest = {
  sample: number;
  wins: number;
  losses: number;
  hitRate: number;
};

export type Quote = {
  assetId: string;
  price: number;
  changePct: number;
  spark: number[];
};

export type LiveSignal = {
  assetId: string;
  interval: Interval;
  direction: Direction;
  confidence: number;
  quality: Quality;
  tradeable: boolean;
  reasons: string[];
  votes: Vote[];
  regime: Regime;
  rsi: number;
  adx: number;
  atrPct: number;
  entryPrice: number;
  issuedAt: number;
  expiryAt: number;
  serverNow: number;
};

export type AssetSnapshot = {
  quote: Quote;
  candles: Candle[];
  signal: LiveSignal | null;
  bias: { direction: Direction; confidence: number } | null;
  backtest: Backtest;
};

export type FeedResponse = {
  interval: Interval;
  serverNow: number;
  snapshots: AssetSnapshot[];
};
