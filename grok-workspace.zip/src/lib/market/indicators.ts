export function sma(values: number[], period: number): Array<number | null> {
  const out: Array<number | null> = Array(values.length).fill(null);
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i]!;
    if (i >= period) sum -= values[i - period]!;
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

export function ema(values: number[], period: number): Array<number | null> {
  const out: Array<number | null> = Array(values.length).fill(null);
  if (values.length < period) return out;
  const k = 2 / (period + 1);
  let prev = 0;
  for (let i = 0; i < period; i++) prev += values[i]!;
  prev /= period;
  out[period - 1] = prev;
  for (let i = period; i < values.length; i++) {
    prev = values[i]! * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

export function rsi(closes: number[], period = 14): Array<number | null> {
  const out: Array<number | null> = Array(closes.length).fill(null);
  if (closes.length <= period) return out;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const diff = closes[i]! - closes[i - 1]!;
    if (diff >= 0) gain += diff;
    else loss -= diff;
  }
  gain /= period;
  loss /= period;
  out[period] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i]! - closes[i - 1]!;
    const g = diff > 0 ? diff : 0;
    const l = diff < 0 ? -diff : 0;
    gain = (gain * (period - 1) + g) / period;
    loss = (loss * (period - 1) + l) / period;
    out[i] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  }
  return out;
}

export function stdev(values: number[], period: number): Array<number | null> {
  const out: Array<number | null> = Array(values.length).fill(null);
  for (let i = period - 1; i < values.length; i++) {
    const slice = values.slice(i - period + 1, i + 1);
    const mean = slice.reduce((a, b) => a + b, 0) / period;
    const variance = slice.reduce((a, b) => a + (b - mean) ** 2, 0) / period;
    out[i] = Math.sqrt(variance);
  }
  return out;
}

export function atr(
  high: number[],
  low: number[],
  close: number[],
  period = 14,
): Array<number | null> {
  const tr: number[] = [high[0]! - low[0]!];
  for (let i = 1; i < close.length; i++) {
    tr.push(
      Math.max(
        high[i]! - low[i]!,
        Math.abs(high[i]! - close[i - 1]!),
        Math.abs(low[i]! - close[i - 1]!),
      ),
    );
  }
  return sma(tr, period);
}

export function macd(closes: number[], fast = 12, slow = 26, signal = 9) {
  const emaFast = ema(closes, fast);
  const emaSlow = ema(closes, slow);
  const line: Array<number | null> = closes.map((_, i) =>
    emaFast[i] != null && emaSlow[i] != null ? emaFast[i]! - emaSlow[i]! : null,
  );
  const compact = line.map((v) => v ?? 0);
  const firstValid = line.findIndex((v) => v != null);
  const signalLine: Array<number | null> = Array(closes.length).fill(null);
  if (firstValid >= 0) {
    const subset = compact.slice(firstValid);
    const sig = ema(subset, signal);
    for (let i = 0; i < sig.length; i++) {
      if (sig[i] != null) signalLine[firstValid + i] = sig[i];
    }
  }
  const hist: Array<number | null> = line.map((v, i) =>
    v != null && signalLine[i] != null ? v - signalLine[i]! : null,
  );
  return { line, signal: signalLine, hist };
}

export function stochastic(
  high: number[],
  low: number[],
  close: number[],
  period = 14,
  smooth = 3,
) {
  const raw: Array<number | null> = Array(close.length).fill(null);
  for (let i = period - 1; i < close.length; i++) {
    let hh = -Infinity;
    let ll = Infinity;
    for (let j = i - period + 1; j <= i; j++) {
      hh = Math.max(hh, high[j]!);
      ll = Math.min(ll, low[j]!);
    }
    const range = hh - ll;
    raw[i] = range === 0 ? 50 : ((close[i]! - ll) / range) * 100;
  }
  const kVals = raw.map((v) => v ?? 0);
  const kSma = sma(kVals, smooth);
  const k: Array<number | null> = raw.map((v, i) => (v == null ? null : (kSma[i] ?? v)));
  const dSeed = k.map((v) => v ?? 0);
  const dSma = sma(dSeed, smooth);
  const d: Array<number | null> = k.map((v, i) => (v == null ? null : (dSma[i] ?? v)));
  return { k, d };
}

export function adx(
  high: number[],
  low: number[],
  close: number[],
  period = 14,
): Array<number | null> {
  const len = close.length;
  const plusDM: number[] = [0];
  const minusDM: number[] = [0];
  const tr: number[] = [high[0]! - low[0]!];
  for (let i = 1; i < len; i++) {
    const up = high[i]! - high[i - 1]!;
    const down = low[i - 1]! - low[i]!;
    plusDM.push(up > down && up > 0 ? up : 0);
    minusDM.push(down > up && down > 0 ? down : 0);
    tr.push(
      Math.max(
        high[i]! - low[i]!,
        Math.abs(high[i]! - close[i - 1]!),
        Math.abs(low[i]! - close[i - 1]!),
      ),
    );
  }
  const smooth = (arr: number[]) => {
    const out: Array<number | null> = Array(len).fill(null);
    if (len <= period) return out;
    let val = 0;
    for (let i = 1; i <= period; i++) val += arr[i]!;
    out[period] = val;
    for (let i = period + 1; i < len; i++) {
      val = val - val / period + arr[i]!;
      out[i] = val;
    }
    return out;
  };
  const smTR = smooth(tr);
  const smP = smooth(plusDM);
  const smM = smooth(minusDM);
  const dx: Array<number | null> = Array(len).fill(null);
  for (let i = 0; i < len; i++) {
    if (smTR[i] == null || smTR[i] === 0 || smP[i] == null || smM[i] == null) continue;
    const plusDI = (100 * smP[i]!) / smTR[i]!;
    const minusDI = (100 * smM[i]!) / smTR[i]!;
    const den = plusDI + minusDI;
    dx[i] = den === 0 ? 0 : (100 * Math.abs(plusDI - minusDI)) / den;
  }
  const out: Array<number | null> = Array(len).fill(null);
  const start = period * 2;
  if (len <= start) return out;
  let acc = 0;
  let count = 0;
  for (let i = period; i <= start; i++) {
    if (dx[i] != null) {
      acc += dx[i]!;
      count++;
    }
  }
  if (count === 0) return out;
  let val = acc / count;
  out[start] = val;
  for (let i = start + 1; i < len; i++) {
    if (dx[i] == null) continue;
    val = (val * (period - 1) + dx[i]!) / period;
    out[i] = val;
  }
  return out;
}

export function lastNumber(arr: Array<number | null | undefined>): number | null {
  for (let i = arr.length - 1; i >= 0; i--) {
    const v = arr[i];
    if (v != null && Number.isFinite(v)) return v;
  }
  return null;
}

export function prevNumber(arr: Array<number | null | undefined>): number | null {
  let found = 0;
  for (let i = arr.length - 1; i >= 0; i--) {
    const v = arr[i];
    if (v != null && Number.isFinite(v)) {
      found++;
      if (found === 2) return v;
    }
  }
  return null;
}
