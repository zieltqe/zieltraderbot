import { ASSETS, INTERVAL_MS, type Asset, type FallbackSource } from "./assets";
import { analyze, toLiveSignal } from "./engine";
import type { Candle, FeedResponse, Interval, Quote } from "./types";

const UA =
  "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36";

type CacheEntry<T> = { at: number; value: T };
const mem = new Map<string, CacheEntry<unknown>>();

function cached<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
  const hit = mem.get(key);
  if (hit && Date.now() - hit.at < ttl) return Promise.resolve(hit.value as T);
  return fn().then((value) => {
    mem.set(key, { at: Date.now(), value });
    return value;
  });
}

async function fetchJson(url: string, timeoutMs = 9000): Promise<unknown> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { "user-agent": UA, accept: "application/json" },
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

function intervalMs(interval: Interval) {
  return INTERVAL_MS[interval];
}

function markClosed(candles: Candle[], interval: Interval, now: number): Candle[] {
  const ms = intervalMs(interval);
  return candles
    .filter((c) => Number.isFinite(c.close) && c.close > 0)
    .map((c) => ({ ...c, closed: c.time + ms <= now + 1500 }));
}

function fromOkx(raw: unknown, interval: Interval, now: number): Candle[] {
  const data = (raw as { data?: string[][] }).data;
  if (!Array.isArray(data)) return [];
  const candles: Candle[] = data
    .map((row) => ({
      time: Number(row[0]),
      open: Number(row[1]),
      high: Number(row[2]),
      low: Number(row[3]),
      close: Number(row[4]),
      volume: Number(row[5] ?? 0),
      closed: row[row.length - 1] === "1",
    }))
    .reverse();
  return markClosed(candles, interval, now);
}

function fromYahoo(raw: unknown, interval: Interval, now: number): Candle[] {
  const result = (raw as { chart?: { result?: Array<Record<string, unknown>> } }).chart
    ?.result?.[0];
  if (!result) return [];
  const ts = (result.timestamp as number[] | undefined) ?? [];
  const quote = (result.indicators as { quote?: Array<Record<string, Array<number | null>>> })
    ?.quote?.[0];
  if (!quote) return [];
  const candles: Candle[] = [];
  for (let i = 0; i < ts.length; i++) {
    const open = quote.open?.[i];
    const high = quote.high?.[i];
    const low = quote.low?.[i];
    const close = quote.close?.[i];
    const volume = quote.volume?.[i];
    if (open == null || high == null || low == null || close == null) continue;
    candles.push({
      time: ts[i]! * 1000,
      open,
      high,
      low,
      close,
      volume: volume ?? 0,
      closed: true,
    });
  }
  return markClosed(candles, interval, now);
}

function fromCoinbase(raw: unknown, interval: Interval, now: number): Candle[] {
  if (!Array.isArray(raw)) return [];
  const candles: Candle[] = (raw as number[][])
    .map((row) => ({
      time: Number(row[0]) * 1000,
      low: Number(row[1]),
      high: Number(row[2]),
      open: Number(row[3]),
      close: Number(row[4]),
      volume: Number(row[5]),
      closed: true,
    }))
    .sort((a, b) => a.time - b.time);
  return markClosed(candles, interval, now);
}

function fromBiquote(raw: unknown, interval: Interval, now: number): Candle[] {
  const bars = (raw as { bars?: Array<Record<string, unknown>> }).bars;
  if (!Array.isArray(bars)) return [];
  const candles: Candle[] = bars
    .map((b) => {
      const t = Date.parse(String(b.openTime ?? ""));
      return {
        time: t,
        open: Number(b.open),
        high: Number(b.high),
        low: Number(b.low),
        close: Number(b.close),
        volume: Number(b.tickVolume ?? b.volume ?? 0),
        closed: b.isOpen !== true,
      };
    })
    .filter((c) => Number.isFinite(c.time) && c.time > 0)
    .sort((a, b) => a.time - b.time);
  return markClosed(candles, interval, now);
}

function fromTwelve(raw: unknown, interval: Interval, now: number): Candle[] {
  const values = (raw as { values?: Array<Record<string, string>> }).values;
  if (!Array.isArray(values)) return [];
  const candles: Candle[] = values
    .map((row) => {
      const stamp = String(row.datetime ?? "").replace(" ", "T");
      const t = Date.parse(stamp.endsWith("Z") ? stamp : `${stamp}Z`);
      return {
        time: t,
        open: Number(row.open),
        high: Number(row.high),
        low: Number(row.low),
        close: Number(row.close),
        volume: Number(row.volume ?? 0),
        closed: true,
      };
    })
    .filter((c) => Number.isFinite(c.time) && c.time > 0)
    .sort((a, b) => a.time - b.time);
  return markClosed(candles, interval, now);
}

async function fetchOkx(instId: string, interval: Interval, now: number): Promise<Candle[]> {
  const bar = interval === "1m" ? "1m" : "5m";
  const url = `https://www.okx.com/api/v5/market/candles?instId=${encodeURIComponent(instId)}&bar=${bar}&limit=120`;
  return fromOkx(await fetchJson(url), interval, now);
}

async function fetchOkxIndex(instId: string, interval: Interval, now: number): Promise<Candle[]> {
  const bar = interval === "1m" ? "1m" : "5m";
  const url = `https://www.okx.com/api/v5/market/index-candles?instId=${encodeURIComponent(instId)}&bar=${bar}&limit=120`;
  return fromOkx(await fetchJson(url), interval, now);
}

async function fetchCoinbase(product: string, interval: Interval, now: number): Promise<Candle[]> {
  const gran = interval === "1m" ? 60 : 300;
  const url = `https://api.exchange.coinbase.com/products/${encodeURIComponent(product)}/candles?granularity=${gran}`;
  return fromCoinbase(await fetchJson(url), interval, now);
}

async function fetchYahoo(ticker: string, interval: Interval, now: number): Promise<Candle[]> {
  const range = interval === "1m" ? "1d" : "5d";
  const hosts = ["query1.finance.yahoo.com", "query2.finance.yahoo.com"];
  let lastErr: unknown;
  for (const host of hosts) {
    const url = `https://${host}/v8/finance/chart/${encodeURIComponent(ticker)}?interval=${interval}&range=${range}&includePrePost=false`;
    try {
      return fromYahoo(await fetchJson(url), interval, now);
    } catch (err) {
      lastErr = err;
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error("Yahoo falhou");
}

async function fetchBiquote(symbol: string, interval: Interval, now: number): Promise<Candle[]> {
  const url = `https://biquote.io/api/${encodeURIComponent(symbol)}/ohlc?interval=${interval}&limit=120`;
  return fromBiquote(await fetchJson(url), interval, now);
}

async function fetchTwelve(symbol: string, interval: Interval, now: number): Promise<Candle[]> {
  const bar = interval === "1m" ? "1min" : "5min";
  const url = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(symbol)}&interval=${bar}&outputsize=120&apikey=demo`;
  return fromTwelve(await fetchJson(url), interval, now);
}

function fallbackFetcher(source: FallbackSource, interval: Interval, now: number): Promise<Candle[]> {
  if (source.kind === "twelve") return fetchTwelve(source.symbol, interval, now);
  if (source.kind === "okx-index") return fetchOkxIndex(source.instId, interval, now);
  if (source.kind === "coinbase") return fetchCoinbase(source.product, interval, now);
  if (source.kind === "okx") return fetchOkx(source.instId, interval, now);
  return fetchYahoo(source.ticker, interval, now);
}

async function loadCandles(asset: Asset, interval: Interval, now: number): Promise<Candle[]> {
  return cached(`candles:${asset.id}:${interval}`, 7000, async () => {
    const attempts: Array<() => Promise<Candle[]>> = [
      () => fetchBiquote(asset.biquote, interval, now),
      ...(asset.fallbacks ?? []).map((source) => () => fallbackFetcher(source, interval, now)),
    ];
    let lastErr: unknown;
    for (const run of attempts) {
      try {
        const rows = await run();
        if (rows.length >= 50) return rows;
        lastErr = new Error("poucos candles");
      } catch (err) {
        lastErr = err;
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("sem candles");
  });
}

function toQuote(assetId: string, candles: Candle[]): Quote {
  const last = candles[candles.length - 1]!;
  const lookback = Math.min(candles.length - 1, intervalLookback(candles));
  const prev = candles[candles.length - 1 - lookback] ?? candles[0]!;
  const changePct = prev.close ? ((last.close - prev.close) / prev.close) * 100 : 0;
  const spark = candles.slice(-28).map((c) => c.close);
  return { assetId, price: last.close, changePct, spark };
}

function intervalLookback(candles: Candle[]) {
  if (candles.length < 3) return 1;
  const step = candles[candles.length - 1]!.time - candles[candles.length - 2]!.time;
  if (step <= 70_000) return Math.min(24 * 60, candles.length - 1);
  return Math.min(24 * 12, candles.length - 1);
}

export async function buildFeed(interval: Interval): Promise<FeedResponse> {
  return cached(`feed:${interval}`, 6000, async () => {
    const now = Date.now();
    const results = await Promise.allSettled(
      ASSETS.map(async (asset) => {
        const candles = await loadCandles(asset, interval, now);
        if (candles.length < 30) throw new Error("poucos candles");
        const analysis = analyze(candles, asset.class);
        const signal = analysis ? toLiveSignal(asset.id, interval, candles, analysis, now) : null;
        return {
          quote: toQuote(asset.id, candles),
          candles: candles.slice(-80),
          signal,
          bias: analysis
            ? { direction: analysis.direction, confidence: analysis.confidence }
            : null,
          backtest: { sample: 0, wins: 0, losses: 0, hitRate: 0 },
        };
      }),
    );

    const snapshots = results.flatMap((r) => (r.status === "fulfilled" ? [r.value] : []));
    snapshots.sort((a, b) => {
      const rank = (id: string) => (id === "eurusd" ? 1 : 0);
      const as = a.signal?.tradeable ? a.signal.confidence : (a.bias?.confidence ?? 0) * 0.4;
      const bs = b.signal?.tradeable ? b.signal.confidence : (b.bias?.confidence ?? 0) * 0.4;
      return rank(b.quote.assetId) - rank(a.quote.assetId) || bs - as;
    });

    return { interval, serverNow: now, snapshots };
  });
}
