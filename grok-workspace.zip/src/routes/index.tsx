import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { getSignalFeed } from "@/lib/market/api";

export const Route = createFileRoute("/")({
  loader: () => getSignalFeed({ data: { interval: "1m" } }),
  component: Home,
});

function Home() {
  const initialFeed = Route.useLoaderData();
  return <AppShell initialFeed={initialFeed} />;
}
